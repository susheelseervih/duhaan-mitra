# DukaanMitra

A mobile-first hiring platform connecting neighbourhood retail shop owners with nearby job
seekers across India. Built as a React + Vite single-page app with hash-based routing.

## Getting started

```bash
npm install
npm run dev
```

Then open the URL Vite prints (usually `http://localhost:5173`).

To build a production bundle:

```bash
npm run build
npm run preview
```

The build output goes to `dist/`.

## Project structure

```
dukaanmitra/
├── index.html              Vite HTML entry point
├── package.json
├── vite.config.js
├── README.md
└── src/
    ├── main.jsx             React root — mounts <App /> inside <AppProvider>
    ├── App.jsx               Top-level router: renders Home / Owner / Seeker pages + global modals
    ├── context.jsx           Global app state: auth, jobs, applications, candidates, modals
    ├── useHashRoute.js        Hash-based routing hook (#/ , #/owner , #/seeker)
    ├── data.js               Mock data: jobs, categories, skills, languages, PIN lookup table
    ├── styles.css            All styling (design tokens, layout, components)
    ├── components/            Reusable UI pieces
    │   ├── Header.jsx / Footer.jsx
    │   ├── Modal.jsx / Toast.jsx / OtpStep.jsx
    │   ├── JobCard.jsx / JobDetailsModal.jsx / JobIdModal.jsx
    │   ├── FilterDrawer.jsx / SavedSearchesModal.jsx
    │   ├── LoginChooserModal.jsx
    │   ├── OwnerAuthModals.jsx    (Owner Login + detailed "Create Dukaan Account" sign-up)
    │   └── SeekerAuthModals.jsx   (Job Finder Login + detailed "Create Mitra Account" sign-up)
    ├── sections/               Homepage sections (Hero, StatsStrip, SpeedTimelines, Features,
    │                           TwoPaths, Scale, Stories, FinalCTA)
    └── pages/
        ├── HomePage.jsx        Marketing homepage
        ├── OwnerPage.jsx        Post a Job form → My Job Posts dashboard → AI-ranked candidates
        └── SeekerPage.jsx       Find a Job search, filters, job details, My Applications
```

## What's implemented

- **Homepage** — hero, speed-to-value timelines, feature showcase, two-path comparison,
  scale section, testimonials, final CTA.
- **Owner flow** — gated behind login/sign-up. Post a job (all fields from the brief),
  see it go live instantly, review AI-ranked candidates with match %, Call/WhatsApp/
  Shortlist/Interview/Hire/Reject actions, and a dashboard listing every job posted with
  a live applicant count.
- **Seeker flow** — browse and filter freely without logging in (distance, category,
  salary, experience, employment type, shift, gender, education, languages, skills,
  benefits, urgent/verified/fresher/walk-in quick filters), list/map toggle, job details
  modal with a real QR code, Apply with Job ID, saved searches with alert toggles, and
  a My Applications tracker with a visual status stepper. **Applying** requires login.
- **Auth** — mobile OTP login for both roles. Sign-up forms match the brief exactly:
  Shop Owner (basic details + shop information with PIN-code auto-fill for city/state)
  and Job Finder / Mitra (personal info, job preferences, languages, and optional
  document uploads — Aadhaar Number is required; Aadhaar/Photo/Resume uploads use real
  `<input type="file">` elements, so mobile browsers offer Camera, Gallery, and Files).

## Notes

- All data is in-memory mock data (`src/data.js`) — there's no backend. Refreshing the
  page resets state.
- The AI match percentages, candidate suggestions, and PIN → city/state lookups are
  deterministic mocks for demonstration, not real services.
- Fonts (Baloo 2, Inter) load from Google Fonts at runtime — an internet connection is
  needed for them to render as intended.
