import React, { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import {
  initialJobs, initialApplications, initialSavedSearches,
  pinLookupTable
} from "./data.js";
import { useHashRoute } from "./useHashRoute.js";
import { loadPersisted, savePersisted, clearPersisted } from "./persist.js";

const AppContext = createContext(null);

// Read once when the module loads (client-side only) so every useState below
// can seed itself from the same snapshot without re-parsing localStorage.
const persisted = loadPersisted();

let jobIdCounter = 200;
if (persisted?.jobs) {
  persisted.jobs.forEach((j) => {
    const match = /^SJ26(\d{4})$/.exec(j.jobId || "");
    if (match) jobIdCounter = Math.max(jobIdCounter, parseInt(match[1], 10));
  });
}
function generateJobId() {
  jobIdCounter += 1;
  return "SJ26" + String(jobIdCounter).padStart(4, "0");
}

function readableDate(isoStr) {
  const d = isoStr ? new Date(isoStr + "T00:00:00") : new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
  const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  return d.getDate() + " " + months[d.getMonth()] + " " + d.getFullYear();
}

function parseSalaryRange(text) {
  const nums = (text.match(/[\d,]+/g) || []).map((n) => parseInt(n.replace(/,/g, ""), 10)).filter((n) => !isNaN(n));
  if (nums.length >= 2) return { min: nums[0], max: nums[1] };
  if (nums.length === 1) return { min: nums[0], max: Math.round(nums[0] * 1.2) };
  return { min: 10000, max: 15000 };
}

export function lookupPin(pin) {
  return pinLookupTable[pin.slice(0, 3)] || null;
}

export function AppProvider({ children }) {
  // ---------- navigation ----------
  const [route, setRoute] = useHashRoute();
  const [ownerView, setOwnerView] = useState("dashboard"); // 'dashboard' | 'postForm' | 'candidates'
  const [activeOwnerJobId, setActiveOwnerJobId] = useState(null);
  const [editingJobId, setEditingJobId] = useState(null);

  const startEditJob = useCallback((jobId) => {
    setEditingJobId(jobId);
    setOwnerView("postForm");
  }, []);
  const startNewJob = useCallback(() => {
    setEditingJobId(null);
    setOwnerView("postForm");
  }, []);

  const goHome = useCallback(() => { setRoute("home"); }, [setRoute]);
  const goOwner = useCallback((view = "dashboard") => {
    setOwnerView(view);
    setEditingJobId(null);
    setRoute("owner");
  }, [setRoute]);
  const goSeeker = useCallback(() => { setRoute("seeker"); }, [setRoute]);

  // ---------- toast ----------
  const [toast, setToast] = useState(null);
  const toastTimer = useRef(null);
  const showToast = useCallback((msg) => {
    setToast(msg);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(null), 2800);
  }, []);

  // ---------- modal control ----------
  const [activeModal, setActiveModal] = useState(null); // 'loginChooser' | 'ownerLogin' | 'ownerSignup' | 'seekerLogin' | 'seekerSignup' | null
  const pendingActionRef = useRef(null);
  const openModal = useCallback((name) => setActiveModal(name), []);
  const closeModal = useCallback(() => setActiveModal(null), []);

  // ---------- owner auth ----------
  const [ownerLoggedIn, setOwnerLoggedIn] = useState(persisted?.ownerLoggedIn || false);
  const [ownerProfile, setOwnerProfile] = useState(persisted?.ownerProfile || { name: "", shop: "" });

  const requireOwnerAuth = useCallback((onSuccess) => {
    if (ownerLoggedIn) { onSuccess(); return; }
    pendingActionRef.current = onSuccess;
    setActiveModal("ownerLogin");
  }, [ownerLoggedIn]);

  const completeOwnerAuth = useCallback((profile) => {
    if (profile) setOwnerProfile(profile);
    setOwnerLoggedIn(true);
    setActiveModal(null);
    const action = pendingActionRef.current;
    pendingActionRef.current = null;
    if (action) action();
    else goOwner("dashboard");
  }, [goOwner]);

  const loginOwner = useCallback((mobile) => {
    if (!ownerProfile.name) setOwnerProfile({ name: "Shop Owner", shop: "Your Shop" });
    showToast("Welcome back!");
    completeOwnerAuth(null);
  }, [ownerProfile, completeOwnerAuth, showToast]);

  // ---------- seeker auth ----------
  const [seekerLoggedIn, setSeekerLoggedIn] = useState(persisted?.seekerLoggedIn || false);
  const [seekerProfile, setSeekerProfile] = useState(persisted?.seekerProfile || { name: "", mobile: "" });

  const requireSeekerAuth = useCallback((onSuccess) => {
    if (seekerLoggedIn) { onSuccess(); return; }
    pendingActionRef.current = onSuccess;
    setActiveModal("seekerLogin");
  }, [seekerLoggedIn]);

  const completeSeekerAuth = useCallback((profile, greeting) => {
    let mergedProfile = null;
    if (profile) {
      setSeekerProfile((prev) => {
        mergedProfile = { ...prev, ...profile };
        return mergedProfile;
      });
    }
    setSeekerLoggedIn(true);
    setActiveModal(null);
    showToast(greeting || "Welcome back!");
    const action = pendingActionRef.current;
    pendingActionRef.current = null;
    // Pass the just-computed profile through directly — React state updates
    // aren't visible synchronously, so reading `seekerProfile` here would still
    // see the pre-login value. The pending action must use what we just set.
    if (action) action(mergedProfile);
    else goSeeker();
  }, [goSeeker, showToast]);

  const loginSeeker = useCallback((mobile) => {
    let mergedProfile = null;
    setSeekerProfile((prev) => {
      mergedProfile = { name: prev.name || "there", mobile: mobile || prev.mobile || "" };
      return mergedProfile;
    });
    // completeSeekerAuth(null,...) would skip re-merging profile since it's already
    // set above; pass it along separately so any pending action still gets it.
    setSeekerLoggedIn(true);
    setActiveModal(null);
    showToast("Welcome back!");
    const action = pendingActionRef.current;
    pendingActionRef.current = null;
    if (action) action(mergedProfile);
    else goSeeker();
  }, [goSeeker, showToast]);

  // ---------- jobs / applications / saved ----------
  // `applications` is the single source of truth for "who applied to what" — it
  // carries the real applicant's name/phone plus their AI match info, so an
  // owner reviewing candidates sees the actual person who applied, not a stand-in.
  const [jobs, setJobs] = useState(persisted?.jobs || initialJobs);
  const [applications, setApplications] = useState(persisted?.applications || initialApplications);
  const [savedJobIds, setSavedJobIds] = useState(new Set(persisted?.savedJobIds || []));
  const [appliedJobIds, setAppliedJobIds] = useState(new Set(persisted?.appliedJobIds || initialApplications.map((a) => a.jobId)));
  const [ownerJobIds, setOwnerJobIds] = useState(persisted?.ownerJobIds || []);

  const toggleSaveJob = useCallback((jobId) => {
    setSavedJobIds((prev) => {
      const next = new Set(prev);
      const job = jobs.find((j) => j.id === jobId);
      if (next.has(jobId)) { next.delete(jobId); showToast((job?.title || "Job") + " removed from saved."); }
      else { next.add(jobId); showToast((job?.title || "Job") + " saved."); }
      return next;
    });
  }, [jobs, showToast]);

  const applyToJob = useCallback((jobId, profileOverride) => {
    if (appliedJobIds.has(jobId)) { showToast("You already applied to this job."); return; }
    const job = jobs.find((j) => j.id === jobId);
    const activeProfile = profileOverride || seekerProfile;
    const name = activeProfile.name && activeProfile.name !== "there" ? activeProfile.name : "Anonymous Applicant";
    const phone = activeProfile.mobile || "";
    const seed = Math.abs((String(jobId) + phone).split("").reduce((a, c) => a + c.charCodeAt(0), 0));
    const matchPct = 82 + (seed % 16); // 82–97%, feels earned rather than arbitrary

    setAppliedJobIds((prev) => new Set(prev).add(jobId));
    setJobs((prev) => prev.map((j) => (j.id === jobId ? { ...j, applicants: j.applicants + 1 } : j)));
    setApplications((prev) => [{
      appId: Date.now(), jobId, name, phone, status: "Applied", appliedDate: "Just now",
      matchPct, meta: "Applied just now · Verified mobile number",
      factors: ["Applied through DukaanMitra", "Mobile OTP verified"]
    }, ...prev]);
    showToast("Applied! Job ID " + (job?.jobId || "") + " — track it under My Applications.");
  }, [appliedJobIds, jobs, seekerProfile, showToast]);

  const handleApplyClick = useCallback((jobId) => {
    if (seekerLoggedIn) { applyToJob(jobId); return; }
    requireSeekerAuth((freshProfile) => applyToJob(jobId, freshProfile));
  }, [seekerLoggedIn, requireSeekerAuth, applyToJob]);

  // ---------- candidates for a job (owner side) — reads real applications directly ----------
  const getApplicantsForJob = useCallback((jobId) => {
    return applications
      .filter((a) => a.jobId === jobId)
      .sort((a, b) => b.matchPct - a.matchPct);
  }, [applications]);

  const setApplicationStatus = useCallback((appId, status) => {
    const app = applications.find((a) => a.appId === appId);
    if (app) showToast(app.name + " moved to " + status + ".");
    setApplications((prev) => prev.map((a) => (a.appId === appId ? { ...a, status } : a)));

    // Hiring someone actually consumes a vacancy — and closes the job once none are left,
    // so it stops showing as open in Find a Job search.
    if (status === "Hired" && app) {
      setJobs((prevJobs) => prevJobs.map((j) => {
        if (j.id !== app.jobId) return j;
        const nextVacancies = Math.max(0, j.vacancies - 1);
        return {
          ...j,
          vacancies: nextVacancies,
          status: nextVacancies === 0 ? "Filled" : j.status
        };
      }));
    }
  }, [applications, showToast]);

  const closeJob = useCallback((jobId) => {
    setJobs((prev) => prev.map((j) => (j.id === jobId ? { ...j, status: "Closed" } : j)));
    showToast("Hiring closed for this job. It's no longer visible in Find a Job search.");
  }, [showToast]);

  const reopenJob = useCallback((jobId) => {
    setJobs((prev) => prev.map((j) => {
      if (j.id !== jobId) return j;
      // A job with 0 vacancies can't meaningfully be "Active" — bump it to 1 so it's
      // actually hireable again rather than reappearing as an empty listing.
      const vacancies = j.vacancies > 0 ? j.vacancies : 1;
      return { ...j, status: "Active", vacancies };
    }));
    showToast("Job reopened — it's live in Find a Job search again.");
  }, [showToast]);

  const updateJob = useCallback((jobId, form) => {
    const { min: salaryMin, max: salaryMax } = parseSalaryRange(form.salary);
    setJobs((prev) => prev.map((j) => {
      if (j.id !== jobId) return j;
      return {
        ...j,
        title: form.title, category: form.category, shop: form.shop,
        area: form.area, city: form.city,
        salaryMin, salaryMax,
        employmentType: form.type === "Full-time" ? "Full-Time" : "Part-Time",
        shift: form.shift, hours: form.hours, education: form.education, gender: form.gender,
        skills: form.skills.length ? form.skills : ["Customer Service"],
        benefits: form.benefits.length ? form.benefits : ["Weekly Off"],
        vacancies: parseInt(form.vacancies) || 1,
        weeklyOff: form.weeklyOff, lastDate: readableDate(form.lastDate), lastDateISO: form.lastDate,
        description: form.description,
        documents: form.documents.length ? form.documents : ["Aadhaar"]
      };
    }));
    showToast("Job details updated.");
    setActiveOwnerJobId(jobId);
    setOwnerView("candidates");
  }, [showToast]);

  // ---------- publish job (owner) ----------
  const publishJob = useCallback((form) => {
    const { min: salaryMin, max: salaryMax } = parseSalaryRange(form.salary);
    const distanceKm = +(Math.random() * 2.5 + 0.3).toFixed(1);
    const travel = distanceKm < 1 ? Math.round(distanceKm * 15) + "-minute walk" : Math.round(distanceKm * 3) + "-minute bike ride";
    const jobId = generateJobId();
    const newJob = {
      id: Date.now(), jobId, title: form.title, shop: form.shop, category: form.category,
      area: form.area, city: form.city, distanceKm, travel, verified: true, urgent: false, walkin: false,
      salaryMin, salaryMax, salaryType: "monthly", experienceLevel: "fresher", education: form.education,
      employmentType: form.type === "Full-time" ? "Full-Time" : "Part-Time", shift: form.shift, hours: form.hours,
      gender: form.gender, languages: ["Kannada", "Hindi", "English"],
      skills: form.skills.length ? form.skills : ["Customer Service"],
      benefits: form.benefits.length ? form.benefits : ["Weekly Off"],
      vacancies: parseInt(form.vacancies) || 1, applicants: 0, posted: "Just now", postedRank: 0,
      weeklyOff: form.weeklyOff, lastDate: readableDate(form.lastDate), lastDateISO: form.lastDate,
      pinTop: Math.round(Math.random() * 70 + 10), pinLeft: Math.round(Math.random() * 70 + 10),
      description: form.description,
      responsibilities: [
        "Assist customers and handle daily counter operations",
        "Support billing and stock organisation",
        "Maintain a clean and welcoming store environment"
      ],
      documents: form.documents.length ? form.documents : ["Aadhaar"],
      reasonTags: ["Just posted", distanceKm + " km away"],
      matchPct: 85, status: "Active"
    };
    setJobs((prev) => [newJob, ...prev]);
    setOwnerJobIds((prev) => [newJob.id, ...prev]);
    showToast("Job published! Job ID " + jobId + " is now live in Find a Job search.");
    setActiveOwnerJobId(newJob.id);
    setOwnerView("candidates");
    return newJob;
  }, [showToast]);

  const viewJobApplicants = useCallback((jobId) => {
    setActiveOwnerJobId(jobId);
    setOwnerView("candidates");
  }, []);

  // ---------- saved searches ----------
  const [savedSearches, setSavedSearches] = useState(persisted?.savedSearches || initialSavedSearches);
  const toggleSearchAlert = useCallback((index) => {
    setSavedSearches((prev) => prev.map((s, i) => (i === index ? { ...s, alertOn: !s.alertOn } : s)));
  }, []);
  const saveCurrentSearch = useCallback((title, sub) => {
    setSavedSearches((prev) => [{ title: title || "My Search " + (prev.length + 1), sub: sub || "All jobs near you", alertOn: true }, ...prev]);
    showToast("Search saved — you'll get alerts for new matches.");
  }, [showToast]);

  // ---------- persist durable state to localStorage on every change ----------
  useEffect(() => {
    savePersisted({
      jobs, applications,
      savedJobIds: [...savedJobIds], appliedJobIds: [...appliedJobIds],
      ownerJobIds, savedSearches,
      ownerLoggedIn, ownerProfile, seekerLoggedIn, seekerProfile
    });
  }, [jobs, applications, savedJobIds, appliedJobIds, ownerJobIds, savedSearches, ownerLoggedIn, ownerProfile, seekerLoggedIn, seekerProfile]);

  const resetAllData = useCallback(() => {
    clearPersisted();
    window.location.hash = "/";
    window.location.reload();
  }, []);

  const value = useMemo(() => ({
    route, goHome, goOwner, goSeeker, ownerView, setOwnerView, activeOwnerJobId,
    editingJobId, startEditJob, startNewJob,
    toast, showToast,
    activeModal, openModal, closeModal,
    ownerLoggedIn, ownerProfile, requireOwnerAuth, loginOwner, completeOwnerAuth,
    seekerLoggedIn, seekerProfile, requireSeekerAuth, loginSeeker, completeSeekerAuth,
    jobs, applications, savedJobIds, appliedJobIds, ownerJobIds,
    toggleSaveJob, applyToJob, handleApplyClick,
    getApplicantsForJob, setApplicationStatus,
    publishJob, viewJobApplicants, closeJob, reopenJob, updateJob,
    savedSearches, toggleSearchAlert, saveCurrentSearch, resetAllData
  }), [
    route, goHome, goOwner, goSeeker, ownerView, activeOwnerJobId, editingJobId, startEditJob, startNewJob, toast, showToast,
    activeModal, openModal, closeModal,
    ownerLoggedIn, ownerProfile, requireOwnerAuth, loginOwner, completeOwnerAuth,
    seekerLoggedIn, seekerProfile, requireSeekerAuth, loginSeeker, completeSeekerAuth,
    jobs, applications, savedJobIds, appliedJobIds, ownerJobIds,
    toggleSaveJob, applyToJob, handleApplyClick, getApplicantsForJob, setApplicationStatus,
    publishJob, viewJobApplicants, closeJob, reopenJob, updateJob,
    savedSearches, toggleSearchAlert, saveCurrentSearch, resetAllData
  ]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
