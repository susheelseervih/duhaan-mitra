import React, { useState } from "react";
import { useApp } from "../context.jsx";

function defaultLastDate() {
  const d = new Date();
  d.setDate(d.getDate() + 30);
  return d.toISOString().split("T")[0];
}

const emptyForm = {
  title: "Sales Assistant", category: "Jewellery Shop", shop: "ABC Kirana Store",
  salary: "₹15,000–20,000/mo", type: "Full-time", vacancies: 1,
  area: "Jayanagar", city: "Bengaluru", hours: "8 Hours", shift: "Flexible",
  weeklyOff: "Monday", lastDate: defaultLastDate(), education: "graduate", gender: "any",
  skills: ["Sales", "Customer Service"], benefits: ["Weekly Off", "Incentives"],
  documents: ["Aadhaar", "Passport Photo"],
  description: "Looking for a friendly, reliable Sales Assistant to help customers, manage the counter, and support daily store operations."
};

function PostJobForm() {
  const { publishJob, updateJob, ownerProfile, editingJobId, jobs, goOwner } = useApp();
  const editingJob = editingJobId ? jobs.find((j) => j.id === editingJobId) : null;

  const initialForm = editingJob ? {
    title: editingJob.title, category: editingJob.category, shop: editingJob.shop,
    salary: editingJob.salaryType === "daily" ? `₹${editingJob.salaryMin}–${editingJob.salaryMax}/day` : `₹${editingJob.salaryMin.toLocaleString("en-IN")}–${editingJob.salaryMax.toLocaleString("en-IN")}/mo`,
    type: editingJob.employmentType === "Full-Time" ? "Full-time" : "Part-time",
    vacancies: editingJob.vacancies, area: editingJob.area, city: editingJob.city,
    hours: editingJob.hours, shift: editingJob.shift, weeklyOff: editingJob.weeklyOff,
    lastDate: editingJob.lastDateISO || defaultLastDate(), education: editingJob.education,
    gender: editingJob.gender, skills: editingJob.skills, benefits: editingJob.benefits,
    documents: editingJob.documents, description: editingJob.description
  } : { ...emptyForm, shop: ownerProfile.shop || emptyForm.shop };

  const [form, setForm] = useState(initialForm);

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));
  const toggleMulti = (key, value) => setForm((f) => ({
    ...f, [key]: f[key].includes(value) ? f[key].filter((v) => v !== value) : [...f[key], value]
  }));

  const submit = () => {
    if (editingJob) updateJob(editingJob.id, form);
    else publishJob(form);
  };

  return (
    <div className="flow-panel">
      <h3>{editingJob ? "Edit job" : "Post a job"}</h3>
      <p className="flow-panel-sub">
        {editingJob
          ? "Update the details below — changes go live in Find a Job search immediately."
          : "Fill in the essentials — most owners finish this in under 2 minutes. This will go live in Find a Job search immediately."}
      </p>

      <div className="flow-form-grid">
        <div className="flow-field"><label>Job Title</label><input type="text" value={form.title} onChange={set("title")} /></div>
        <div className="flow-field">
          <label>Shop Category</label>
          <select value={form.category} onChange={set("category")}>
            {["Kirana Store","Jewellery Shop","Medical Store","Bakery","Mobile Shop","Textile Shop","Hardware Store"].map((c) => <option key={c}>{c}</option>)}
          </select>
        </div>
        <div className="flow-field"><label>Shop Name</label><input type="text" value={form.shop} onChange={set("shop")} /></div>
        <div className="flow-field"><label>Salary Range</label><input type="text" value={form.salary} onChange={set("salary")} /></div>
        <div className="flow-field">
          <label>Job Type</label>
          <select value={form.type} onChange={set("type")}><option>Full-time</option><option>Part-time</option></select>
        </div>
        <div className="flow-field"><label>Number of Vacancies</label><input type="number" min="1" value={form.vacancies} onChange={set("vacancies")} /></div>
        <div className="flow-field"><label>Area / Locality</label><input type="text" value={form.area} onChange={set("area")} /></div>
        <div className="flow-field"><label>City</label><input type="text" value={form.city} onChange={set("city")} /></div>
        <div className="flow-field"><label>Working Hours</label><input type="text" value={form.hours} onChange={set("hours")} /></div>
        <div className="flow-field">
          <label>Shift</label>
          <select value={form.shift} onChange={set("shift")}>{["Morning","Afternoon","Evening","Night","Flexible"].map((s) => <option key={s}>{s}</option>)}</select>
        </div>
        <div className="flow-field"><label>Weekly Off</label><input type="text" value={form.weeklyOff} onChange={set("weeklyOff")} /></div>
        <div className="flow-field"><label>Last Date to Apply</label><input type="date" value={form.lastDate} onChange={set("lastDate")} /></div>
        <div className="flow-field">
          <label>Education Required</label>
          <select value={form.education} onChange={set("education")}>
            <option value="none">No Education Required</option><option value="8th">8th Pass</option>
            <option value="10th">10th Pass</option><option value="12th">12th Pass / PUC</option>
            <option value="diploma">Diploma</option><option value="graduate">Graduate</option><option value="postgrad">Post Graduate</option>
          </select>
        </div>
        <div className="flow-field">
          <label>Gender Preference</label>
          <select value={form.gender} onChange={set("gender")}>
            <option value="any">No Preference</option><option value="male">Male Preferred</option><option value="female">Female Preferred</option>
          </select>
        </div>
      </div>

      <div className="flow-section-divider"><h4>Skills required</h4><div className="fline" /></div>
      <div className="flow-check-group">
        {["Sales","Customer Service","Billing","Jewellery Sales","Stock Management"].map((s) => (
          <label key={s} className="flow-check-pill"><input type="checkbox" checked={form.skills.includes(s)} onChange={() => toggleMulti("skills", s)} /> {s}</label>
        ))}
      </div>

      <div className="flow-section-divider"><h4>Benefits offered</h4><div className="fline" /></div>
      <div className="flow-check-group">
        {["Weekly Off","PF","Incentives","Festival Bonus","Free Food","Uniform Provided"].map((b) => (
          <label key={b} className="flow-check-pill"><input type="checkbox" checked={form.benefits.includes(b)} onChange={() => toggleMulti("benefits", b)} /> {b}</label>
        ))}
      </div>

      <div className="flow-section-divider"><h4>Documents required from applicant</h4><div className="fline" /></div>
      <div className="flow-check-group">
        {["Aadhaar","PAN","Driving License","Resume","Passport Photo"].map((d) => (
          <label key={d} className="flow-check-pill"><input type="checkbox" checked={form.documents.includes(d)} onChange={() => toggleMulti("documents", d)} /> {d}</label>
        ))}
      </div>

      <div className="flow-section-divider"><h4>Job description</h4><div className="fline" /></div>
      <div className="flow-field full"><textarea rows={4} value={form.description} onChange={set("description")} /></div>

      <div className="flow-form-actions">
        <button className="btn btn-outline" onClick={() => goOwner("dashboard")}>Cancel</button>
        <button className="btn btn-primary" onClick={submit}>{editingJob ? "Save Changes" : "Publish Job"}</button>
      </div>
    </div>
  );
}

function Dashboard() {
  const { jobs, ownerJobIds, viewJobApplicants, startEditJob, startNewJob, closeJob, reopenJob } = useApp();
  const list = ownerJobIds.map((id) => jobs.find((j) => j.id === id)).filter(Boolean);

  const statusBadge = (status) => {
    const styles = {
      Active: { background: "#EAF7E9", color: "var(--green)" },
      Filled: { background: "#E9F1F7", color: "var(--navy)" },
      Closed: { background: "#EDEFF0", color: "var(--ink-soft)" }
    };
    const s = styles[status] || styles.Active;
    return <span style={{ ...s, fontSize: "0.7rem", fontWeight: 700, padding: "4px 10px", borderRadius: 999, whiteSpace: "nowrap" }}>{status}</span>;
  };

  return (
    <div className="flow-panel">
      <h3>My job posts</h3>
      <p className="flow-panel-sub">Every job you've published, with live applicant counts pulled straight from Find a Job search.</p>
      {list.length === 0 ? (
        <div className="jf-empty-state" style={{ padding: "30px 10px" }}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 9l1-5h16l1 5" /><path d="M5 9v10h14V9" /></svg>
          You haven't posted any jobs yet.
        </div>
      ) : (
        list.map((job) => {
          const salaryLabel = job.salaryType === "daily" ? `₹${job.salaryMin}–₹${job.salaryMax}/day` : `₹${job.salaryMin.toLocaleString("en-IN")}–₹${job.salaryMax.toLocaleString("en-IN")}/mo`;
          return (
            <div key={job.id} style={{ display: "flex", alignItems: "center", gap: 16, padding: "16px 0", borderBottom: "1px solid var(--line)", flexWrap: "wrap" }}>
              <div style={{ flex: 1, minWidth: 180 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                  <span style={{ fontWeight: 700, color: "var(--navy-dark)", fontSize: "0.95rem" }}>{job.title}</span>
                  {statusBadge(job.status)}
                </div>
                <div style={{ fontSize: "0.8rem", color: "var(--ink-soft)", marginTop: 3 }}>{job.category} · {job.area}, {job.city} · {salaryLabel} · {job.vacancies} vacancy left · Job ID: {job.jobId}</div>
              </div>
              <div style={{ textAlign: "center", flexShrink: 0 }}>
                <div style={{ fontFamily: "'Baloo 2'", fontWeight: 700, fontSize: "1.2rem", color: "var(--navy-dark)" }}>{job.applicants}</div>
                <div style={{ fontSize: "0.65rem", color: "var(--ink-soft)" }}>Applicants</div>
              </div>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                <button className="btn btn-primary btn-sm" onClick={() => viewJobApplicants(job.id)}>View Applicants</button>
                <button className="btn btn-outline btn-sm" onClick={() => startEditJob(job.id)}>Edit</button>
                {job.status === "Active" && (
                  <button className="btn btn-outline btn-sm" onClick={() => closeJob(job.id)}>Close Hiring</button>
                )}
                {job.status !== "Active" && (
                  <button className="btn btn-outline btn-sm" onClick={() => reopenJob(job.id)}>Reopen</button>
                )}
              </div>
            </div>
          );
        })
      )}
      <div className="flow-form-actions" style={{ justifyContent: "flex-start" }}>
        <button className="btn btn-primary" onClick={startNewJob}>+ Post Another Job</button>
      </div>
    </div>
  );
}

function CandidatesView() {
  const { jobs, activeOwnerJobId, getApplicantsForJob, setApplicationStatus, setOwnerView, showToast, goSeeker, closeJob, reopenJob } = useApp();
  const job = jobs.find((j) => j.id === activeOwnerJobId);
  if (!job) return <Dashboard />;
  const candidates = getApplicantsForJob(job.id);
  const salaryLabel = job.salaryType === "daily" ? `₹${job.salaryMin}–₹${job.salaryMax}/day` : `₹${job.salaryMin.toLocaleString("en-IN")}–₹${job.salaryMax.toLocaleString("en-IN")}/mo`;

  const copyJobId = () => {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(job.jobId).then(() => showToast("Job ID copied: " + job.jobId)).catch(() => showToast("Job ID: " + job.jobId));
    } else showToast("Job ID: " + job.jobId);
  };
  const shareJobId = () => {
    const msg = `Hiring at ${job.shop}.\n\nJob Title: ${job.title}\nSalary: ${salaryLabel}\nLocation: ${job.area}, ${job.city}\nJob ID: ${job.jobId}\n\nOpen DukaanMitra → Enter Job ID → Apply instantly.`;
    window.open("https://wa.me/?text=" + encodeURIComponent(msg), "_blank");
  };
  const callCandidate = (c) => showToast("Calling " + c.name + (c.phone ? " at +91 " + c.phone : "") + "...");
  const whatsappCandidate = (c) => {
    const msg = `Hi, we received your application for ${job.title} at ${job.shop}. Please come for an interview tomorrow at 10 AM.`;
    window.open("https://wa.me/91" + (c.phone || "") + "?text=" + encodeURIComponent(msg), "_blank");
  };
  const initials = (name) => name.split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();

  return (
    <div>
      <div className="flow-job-summary">
        <div className="flow-job-summary-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 9l1-5h16l1 5" /><path d="M5 9v10h14V9" /></svg></div>
        <div>
          <div className="flow-job-summary-title">{job.title}</div>
          <div className="flow-job-summary-sub">{job.shop} · {salaryLabel}</div>
          <div style={{ fontSize: "0.78rem", color: "var(--ink-soft)", marginTop: 4 }}>Job ID: <strong style={{ color: "var(--navy-dark)" }}>{job.jobId}</strong></div>
        </div>
        <span className="flow-job-summary-badge" style={
          job.status === "Filled" ? { background: "#E9F1F7", color: "var(--navy)" } :
          job.status === "Closed" ? { background: "#EDEFF0", color: "var(--ink-soft)" } : undefined
        }>
          {job.status === "Active" ? "Live in Find a Job search" : job.status === "Filled" ? "Filled — no longer accepting applicants" : "Closed by you"}
        </span>
      </div>

      {job.status === "Active" ? (
        <div style={{ textAlign: "right", marginBottom: 12 }}>
          <button className="btn btn-outline btn-sm" onClick={() => closeJob(job.id)}>Close Hiring</button>
        </div>
      ) : (
        <div style={{ textAlign: "right", marginBottom: 12 }}>
          <button className="btn btn-outline btn-sm" onClick={() => reopenJob(job.id)}>Reopen Job</button>
        </div>
      )}

      <div className="flow-panel" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 14, flexWrap: "wrap" }}>
        <div style={{ fontSize: "0.85rem", color: "var(--ink-soft)" }}>Share this Job ID so anyone can apply directly, even without browsing.</div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <button className="btn btn-outline btn-sm" onClick={copyJobId}>Copy Job ID</button>
          <button className="btn btn-primary btn-sm" onClick={shareJobId}>Share via WhatsApp</button>
        </div>
      </div>

      <h3 style={{ fontSize: "1.05rem", marginBottom: 14 }}>AI-ranked candidates</h3>

      {candidates.length === 0 ? (
        <div className="jf-empty-state" style={{ padding: "30px 10px" }}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /></svg>
          No applicants yet for this job. Share the Job ID above to reach candidates faster —
          they'll show up here the moment they apply.
        </div>
      ) : candidates.map((c, i) => (
        <div className="flow-match-card" key={c.appId}>
          <div className="flow-match-top">
            <div className="flow-match-avatar-row">
              <div className="flow-match-avatar">{initials(c.name)}</div>
              <div>
                <div className="flow-match-name">{i === 0 ? "🏆 " : ""}{c.name}</div>
                <div className="flow-match-meta">{c.meta}</div>
              </div>
            </div>
            <div>
              <div className="flow-match-pct" style={{ color: c.matchPct >= 90 ? "var(--green)" : "var(--saffron-dark)" }}>{c.matchPct}%</div>
              <div className="flow-match-pct-label">Match</div>
            </div>
          </div>
          <div className="flow-factor-tags">{c.factors.map((f) => <span key={f} className="flow-factor-tag">{f}</span>)}</div>
          <div className="flow-stage-row">
            <span style={{ fontSize: "0.78rem", color: "var(--ink-soft)" }}>Stage:</span>
            <span className={"flow-stage-pill flow-stage-" + c.status.replace(/\s/g, "")}>{c.status}</span>
          </div>
          <div className="flow-action-row">
            <button className="flow-chip-btn call" onClick={() => callCandidate(c)}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z" /></svg>
              Call
            </button>
            <button className="flow-chip-btn whatsapp" onClick={() => whatsappCandidate(c)}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" /></svg>
              WhatsApp Candidate
            </button>
            {c.status !== "Shortlisted" && c.status !== "Interview Scheduled" && c.status !== "Hired" && c.status !== "Rejected" && (
              <button className="flow-chip-btn" onClick={() => setApplicationStatus(c.appId, "Shortlisted")}>Shortlist</button>
            )}
            {c.status === "Shortlisted" && (
              <button className="flow-chip-btn" onClick={() => setApplicationStatus(c.appId, "Interview Scheduled")}>Schedule Interview</button>
            )}
            {(c.status === "Interview Scheduled" || c.status === "Shortlisted") && (
              <button className="flow-chip-btn hired" onClick={() => setApplicationStatus(c.appId, "Hired")}>Mark Hired</button>
            )}
            {c.status !== "Hired" && c.status !== "Rejected" && (
              <button className="flow-chip-btn reject" onClick={() => setApplicationStatus(c.appId, "Rejected")}>Reject</button>
            )}
            {c.status === "Rejected" && (
              <button className="flow-chip-btn" onClick={() => setApplicationStatus(c.appId, "Applied")}>Undo Reject</button>
            )}
          </div>
        </div>
      ))}

      <div style={{ textAlign: "center", marginTop: 28, display: "flex", gap: 10, justifyContent: "center", flexWrap: "wrap" }}>
        <button className="btn btn-outline" onClick={() => setOwnerView("dashboard")}>Back to My Job Posts</button>
        <button className="btn btn-outline" onClick={goSeeker}>See It Live in Find a Job</button>
      </div>
    </div>
  );
}

export default function OwnerPage() {
  const { ownerView, setOwnerView, ownerJobIds, goHome } = useApp();

  return (
    <section id="ownerFlowSection" style={{ display: "block" }}>
      <div className="flow-wrap">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12, marginBottom: 24 }}>
          <button className="flow-back" style={{ marginBottom: 0 }} onClick={goHome}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="19" y1="12" x2="5" y2="12" /><polyline points="12 19 5 12 12 5" /></svg>
            Back to Home
          </button>
          <button className="btn btn-outline btn-sm" onClick={() => setOwnerView("dashboard")}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ width: 14, height: 14 }}><rect x="3" y="3" width="7" height="9" /><rect x="14" y="3" width="7" height="5" /><rect x="14" y="12" width="7" height="9" /><rect x="3" y="16" width="7" height="5" /></svg>
            {" "}My Job Posts{" "}
            <span style={{ background: "var(--saffron)", color: "var(--navy-dark)", fontSize: "0.68rem", fontWeight: 700, padding: "2px 7px", borderRadius: 999 }}>{ownerJobIds.length}</span>
          </button>
        </div>

        {ownerView === "dashboard" && <Dashboard />}
        {ownerView === "postForm" && <PostJobForm />}
        {ownerView === "candidates" && <CandidatesView />}
      </div>
    </section>
  );
}
