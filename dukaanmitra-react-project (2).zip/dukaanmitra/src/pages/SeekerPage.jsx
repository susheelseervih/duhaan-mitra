import React, { useMemo, useState } from "react";
import { useApp } from "../context.jsx";
import JobCard from "../components/JobCard.jsx";
import FilterDrawer, { defaultFilters } from "../components/FilterDrawer.jsx";
import JobDetailsModal from "../components/JobDetailsModal.jsx";
import JobIdModal from "../components/JobIdModal.jsx";
import SavedModal from "../components/SavedModal.jsx";
import { applicationSteps, applicationStatusColors } from "../data.js";

const PAGE_SIZE = 6;

function salaryRangeMatches(job, key) {
  if (key === "any") return true;
  const ranges = { "5-10": [5000, 10000], "10-15": [10000, 15000], "15-20": [15000, 20000], "20-30": [20000, 30000], "30-50": [30000, 50000], "50+": [50000, Infinity] };
  const [lo, hi] = ranges[key];
  return job.salaryMax >= lo && job.salaryMin <= hi;
}
function genderMatches(job, key) {
  if (key === "any") return true;
  if (key === "none") return job.gender === "any";
  return job.gender === key;
}

function matchesAllFilters(job, filters, query) {
  if (query) {
    const hay = [job.title, job.shop, job.category, job.area, job.city, job.jobId].join(" ").toLowerCase();
    if (!hay.includes(query.toLowerCase())) return false;
  }
  if (filters.distance !== "any" && job.distanceKm > parseInt(filters.distance)) return false;
  if (filters.categories.size && !filters.categories.has(job.category)) return false;
  if (!salaryRangeMatches(job, filters.salary)) return false;
  if (filters.salaryType !== "any" && job.salaryType !== filters.salaryType) return false;
  if (filters.experience !== "any" && job.experienceLevel !== filters.experience) return false;
  if (filters.employmentTypes.size && !filters.employmentTypes.has(job.employmentType)) return false;
  if (filters.shifts.size && !filters.shifts.has(job.shift)) return false;
  if (!genderMatches(job, filters.gender)) return false;
  if (filters.education !== "any" && job.education !== filters.education) return false;
  if (filters.languages.size && ![...filters.languages].some((l) => job.languages.includes(l))) return false;
  if (filters.skills.size && ![...filters.skills].some((s) => job.skills.includes(s))) return false;
  if (filters.benefits.size && ![...filters.benefits].some((b) => job.benefits.includes(b))) return false;
  if (filters.urgentOnly && !job.urgent) return false;
  if (filters.verifiedOnly && !job.verified) return false;
  if (filters.freshersOnly && job.experienceLevel !== "fresher") return false;
  if (filters.walkinOnly && !job.walkin) return false;
  return true;
}

function sortJobs(list, sort) {
  const arr = [...list];
  switch (sort) {
    case "salaryHigh": return arr.sort((a, b) => b.salaryMax - a.salaryMax);
    case "salaryLow": return arr.sort((a, b) => a.salaryMin - b.salaryMin);
    case "latest": return arr.sort((a, b) => a.postedRank - b.postedRank);
    case "urgent": return arr.sort((a, b) => (b.urgent - a.urgent) || (a.distanceKm - b.distanceKm));
    case "verified": return arr.sort((a, b) => (b.verified - a.verified) || (a.distanceKm - b.distanceKm));
    case "applied": return arr.sort((a, b) => b.applicants - a.applicants);
    default: return arr.sort((a, b) => a.distanceKm - b.distanceKm);
  }
}

function applicationStepperHtml(status) {
  if (status === "Rejected") {
    return (
      <div className="japp-stepper">
        {applicationSteps.slice(0, 2).map((s, i) => (
          <div className="japp-step-node" key={s}>
            {i > 0 && <div className="japp-step-line done" />}
            <div className="japp-step-circle done">✓</div>
            <div className="japp-step-label">{s}</div>
          </div>
        ))}
        <div className="japp-step-node">
          <div className="japp-step-line" />
          <div className="japp-step-circle rejected">✕</div>
          <div className="japp-step-label">Rejected</div>
        </div>
      </div>
    );
  }
  const currentIndex = applicationSteps.indexOf(status);
  return (
    <div className="japp-stepper">
      {applicationSteps.map((s, i) => (
        <div className="japp-step-node" key={s}>
          {i > 0 && <div className={"japp-step-line" + (i <= currentIndex ? " done" : "")} />}
          <div className={"japp-step-circle" + (i < currentIndex ? " done" : i === currentIndex ? " current" : "")}>
            {i < currentIndex ? "✓" : i + 1}
          </div>
          <div className="japp-step-label">{s}</div>
        </div>
      ))}
    </div>
  );
}

function ApplicationsView({ jobs, applications, onViewJob, onBack }) {
  return (
    <div className="jf-content">
      <div className="jf-section-title" style={{ marginBottom: 20 }}>
        <h3>My Applications</h3>
        <span style={{ fontSize: "0.78rem", color: "var(--ink-soft)" }}>{applications.length} application{applications.length !== 1 ? "s" : ""}</span>
      </div>
      {applications.length === 0 ? (
        <div className="jf-empty-state">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 11l3 3L22 4" /><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" /></svg>
          You haven't applied to any jobs yet. Browse jobs and hit Apply to start tracking them here.
        </div>
      ) : (
        applications.map((a) => {
          const job = jobs.find((j) => j.id === a.jobId);
          if (!job) return null;
          const salaryLabel = job.salaryType === "daily" ? `₹${job.salaryMin}–₹${job.salaryMax}/day` : `₹${job.salaryMin.toLocaleString("en-IN")}–₹${job.salaryMax.toLocaleString("en-IN")}/mo`;
          return (
            <div className="japp-card" key={a.appId}>
              <div className="japp-top">
                <div>
                  <div className="japp-title">{job.title}</div>
                  <div className="japp-shop">{job.shop} · {job.area}, {job.city} · Applied {a.appliedDate}</div>
                  <div className="japp-jobid">Job ID: {job.jobId}</div>
                </div>
                <span className="japp-status-badge" style={{ background: applicationStatusColors[a.status] + "1A", color: applicationStatusColors[a.status] }}>{a.status}</span>
              </div>
              {applicationStepperHtml(a.status)}
              <div className="japp-foot-row">
                <span style={{ fontSize: "0.8rem", fontWeight: 700, color: "var(--green)" }}>{salaryLabel}</span>
                <button className="btn btn-outline btn-sm" onClick={() => { onBack(); onViewJob(job); }}>View Job</button>
              </div>
            </div>
          );
        })
      )}
    </div>
  );
}

export default function SeekerPage() {
  const { jobs, applications, goHome, showToast } = useApp();

  const [subView, setSubView] = useState("search"); // 'search' | 'applications'
  const [query, setQuery] = useState("");
  const [filters, setFilters] = useState(defaultFilters());
  const [sort, setSort] = useState("nearest");
  const [view, setView] = useState("list"); // 'list' | 'map'
  const [page, setPage] = useState(1);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [savedOpen, setSavedOpen] = useState(false);
  const [jobIdOpen, setJobIdOpen] = useState(false);
  const [detailsJob, setDetailsJob] = useState(null);
  const [locationLabel, setLocationLabel] = useState("JP Nagar, Bengaluru");

  const filtered = useMemo(() => sortJobs(jobs.filter((j) => j.status === "Active" && matchesAllFilters(j, filters, query)), sort), [jobs, filters, query, sort]);
  const visible = filtered.slice(0, page * PAGE_SIZE);
  const recommended = useMemo(() => [...jobs].filter((j) => j.status === "Active").sort((a, b) => b.matchPct - a.matchPct).slice(0, 4), [jobs]);

  const toggleQuickFilter = (key) => { setFilters((f) => ({ ...f, [key]: !f[key] })); setPage(1); };

  const shareJobWhatsapp = (job) => {
    const salaryLabel = job.salaryType === "daily" ? `₹${job.salaryMin}–₹${job.salaryMax}/day` : `₹${job.salaryMin.toLocaleString("en-IN")}–₹${job.salaryMax.toLocaleString("en-IN")}`;
    const msg = `Hiring at ${job.shop}.\n\nJob Title: ${job.title}\nSalary: ${salaryLabel}\nLocation: ${job.area}, ${job.city}\nJob ID: ${job.jobId}\n\nOpen DukaanMitra → Enter Job ID → Apply instantly.`;
    window.open("https://wa.me/?text=" + encodeURIComponent(msg), "_blank");
  };

  const useGPS = () => {
    if (!navigator.geolocation) { showToast("Location access is not supported on this browser."); return; }
    navigator.geolocation.getCurrentPosition(
      () => { setLocationLabel("your current location"); showToast("Location detected — showing nearby jobs."); },
      () => showToast("Location permission denied. Showing jobs for your saved area instead.")
    );
  };

  const startVoiceSearch = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { showToast("Voice search is not supported on this browser."); return; }
    try {
      const rec = new SR();
      rec.lang = "en-IN";
      rec.onresult = (e) => setQuery(e.results[0][0].transcript);
      rec.onerror = () => showToast("Could not hear you — try typing instead.");
      rec.start();
      showToast("Listening...");
    } catch (err) { showToast("Voice search is not available right now."); }
  };

  const applicationsForList = applications; // already newest-first by construction

  return (
    <section id="seekerFlowSection" style={{ display: "block" }}>
      <div style={{ maxWidth: 1180, margin: "0 auto", padding: "14px 24px 0" }}>
        <button className="flow-back" onClick={goHome}>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="19" y1="12" x2="5" y2="12" /><polyline points="12 19 5 12 12 5" /></svg>
          Back to Home
        </button>
      </div>

      <div className="jf-topbar">
        <div className="jf-brand-row">
          <div className="jf-brand">Dukaan<span>Mitra</span></div>
          <div className="jf-topbar-actions">
            <button className="jf-icon-btn" onClick={() => setSavedOpen(true)} aria-label="Saved searches">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" /></svg>
            </button>
            <button className="jf-icon-btn" onClick={() => setJobIdOpen(true)} aria-label="Apply with Job ID">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="7" width="18" height="13" rx="2" /><path d="M16 3v8" /><path d="M8 3v8" /><path d="M3 11h18" /></svg>
            </button>
            <button className="jf-icon-btn" onClick={() => setSubView("applications")} aria-label="My Applications">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 11l3 3L22 4" /><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" /></svg>
              <span className="jf-count-dot">{applications.length}</span>
            </button>
          </div>
        </div>

        {subView === "search" && (
          <>
            <div className="jf-search-row">
              <div className="jf-search-bar">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" /></svg>
                <input type="text" placeholder="Job title, shop, category, area, or Job ID..." value={query} onChange={(e) => { setQuery(e.target.value); setPage(1); }} />
                <button className="jf-mic-btn" onClick={startVoiceSearch} aria-label="Voice search">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" /><path d="M19 10v2a7 7 0 0 1-14 0v-2" /><line x1="12" y1="19" x2="12" y2="23" /></svg>
                </button>
              </div>
              <button className="jf-gps-btn" onClick={useGPS}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 10c0 7-9 12-9 12s-9-5-9-12a9 9 0 0 1 18 0z" /><circle cx="12" cy="10" r="3" /></svg>
                Near Me
              </button>
            </div>
            <div className="jf-location-banner">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M20 6L9 17l-5-5" /></svg>
              Showing jobs within <strong>5 km</strong> of <strong>{locationLabel}</strong>
            </div>
            <div className="jf-toolbar">
              <button className="jf-chip" onClick={() => setDrawerOpen(true)}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="4" y1="21" x2="4" y2="14" /><line x1="4" y1="10" x2="4" y2="3" /><line x1="12" y1="21" x2="12" y2="12" /><line x1="12" y1="8" x2="12" y2="3" /><line x1="20" y1="21" x2="20" y2="16" /><line x1="20" y1="12" x2="20" y2="3" /></svg>
                All Filters
              </button>
              <button className={"jf-chip urgent" + (filters.urgentOnly ? " active" : "")} onClick={() => toggleQuickFilter("urgentOnly")}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M13 2L3 14h8l-1 8 10-12h-8z" /></svg>
                Urgent Hiring
              </button>
              <button className={"jf-chip verified" + (filters.verifiedOnly ? " active" : "")} onClick={() => toggleQuickFilter("verifiedOnly")}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2l9 4.5v6c0 5-3.5 8-9 9.5-5.5-1.5-9-4.5-9-9.5v-6z" /><path d="M9 12l2 2 4-4" /></svg>
                Verified Shops
              </button>
              <button className={"jf-chip" + (filters.freshersOnly ? " active" : "")} onClick={() => toggleQuickFilter("freshersOnly")}>Freshers Welcome</button>
              <button className={"jf-chip" + (filters.walkinOnly ? " active" : "")} onClick={() => toggleQuickFilter("walkinOnly")}>Walk-in Interview</button>
            </div>
          </>
        )}
      </div>

      {subView === "applications" ? (
        <ApplicationsView jobs={jobs} applications={applicationsForList} onViewJob={setDetailsJob} onBack={() => setSubView("search")} />
      ) : (
        <div className="jf-content">
          <div className="jf-jobid-banner">
            <div className="jf-jobid-banner-text">
              <strong>Know a Job ID?</strong>
              Someone shared a job over call or WhatsApp — apply directly, no searching needed.
            </div>
            <button className="btn btn-primary btn-sm" onClick={() => setJobIdOpen(true)}>Apply with Job ID</button>
          </div>

          <div className="jf-section-title">
            <h3>Recommended for you</h3>
            <span style={{ fontSize: "0.78rem", color: "var(--ink-soft)" }}>Based on your profile &amp; location</span>
          </div>
          <div className="jf-reco-scroll">
            {recommended.map((j) => (
              <div className="jf-reco-card" key={j.id} onClick={() => setDetailsJob(j)}>
                <div className="jf-reco-top">
                  <div className="jf-reco-title">{j.title}</div>
                  <div className="jf-reco-pct">{j.matchPct}%</div>
                </div>
                <div className="jf-reco-shop">{j.shop} · {j.distanceKm} km</div>
                <div className="jf-reco-tags">{j.reasonTags.map((t) => <span key={t} className="jf-reco-tag">{t}</span>)}</div>
              </div>
            ))}
          </div>

          <div className="jf-results-head">
            <div className="jf-results-count"><strong>{filtered.length}</strong> jobs found near you</div>
            <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
              <select className="jf-sort-select" value={sort} onChange={(e) => setSort(e.target.value)}>
                <option value="nearest">Nearest First</option>
                <option value="salaryHigh">Highest Salary</option>
                <option value="salaryLow">Lowest Salary</option>
                <option value="latest">Latest Posted</option>
                <option value="urgent">Urgent Hiring</option>
                <option value="verified">Verified Shops</option>
                <option value="applied">Most Applied</option>
              </select>
              <div className="jf-view-toggle">
                <button className={"jf-view-btn" + (view === "list" ? " active" : "")} onClick={() => setView("list")}>
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><line x1="8" y1="6" x2="21" y2="6" /><line x1="8" y1="12" x2="21" y2="12" /><line x1="8" y1="18" x2="21" y2="18" /><line x1="3" y1="6" x2="3.01" y2="6" /><line x1="3" y1="12" x2="3.01" y2="12" /><line x1="3" y1="18" x2="3.01" y2="18" /></svg>
                  List
                </button>
                <button className={"jf-view-btn" + (view === "map" ? " active" : "")} onClick={() => setView("map")}>
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6" /></svg>
                  Map
                </button>
              </div>
            </div>
          </div>

          {view === "list" ? (
            <>
              <div className="jf-job-grid">
                {visible.length === 0 ? (
                  <div className="jf-empty-state">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" /></svg>
                    No jobs match your filters. Try widening the distance radius.
                  </div>
                ) : (
                  visible.map((job) => <JobCard key={job.id} job={job} onOpenDetails={setDetailsJob} onShare={shareJobWhatsapp} />)
                )}
              </div>
              {filtered.length > visible.length && (
                <div className="jf-load-more"><button className="btn btn-outline" onClick={() => setPage((p) => p + 1)}>Load More Jobs</button></div>
              )}
            </>
          ) : (
            <div className="jf-map-view show">
              <div className="jf-map-you" />
              {filtered.map((j) => (
                <div key={j.id} className="jf-map-pin" style={{ top: j.pinTop + "%", left: j.pinLeft + "%" }} onClick={() => setDetailsJob(j)}>
                  <div className={"jf-map-pin-dot" + (j.urgent ? " urgent" : "")}><span>₹</span></div>
                  <div className="jf-map-pin-label">{j.title}</div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      <FilterDrawer
        open={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        filters={filters}
        setFilters={setFilters}
        onApply={() => { setDrawerOpen(false); setPage(1); showToast("Filters applied."); }}
        onClear={() => { setFilters(defaultFilters()); setPage(1); }}
      />

      <JobDetailsModal job={detailsJob} onClose={() => setDetailsJob(null)} onShare={shareJobWhatsapp} onReport={() => { showToast("Job reported. Our team will review it shortly."); setDetailsJob(null); }} />
      <JobIdModal show={jobIdOpen} onClose={() => setJobIdOpen(false)} onViewDetails={setDetailsJob} />
      <SavedModal show={savedOpen} onClose={() => setSavedOpen(false)} currentQuery={query} onOpenDetails={setDetailsJob} />

      <div className="jf-bottom-nav">
        <button className={"jf-bn-item" + (subView === "search" ? " active" : "")} onClick={() => setSubView("search")}>
          <svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round"><circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" /></svg>
          Search
        </button>
        <button className="jf-bn-item" onClick={() => setSavedOpen(true)}>
          <svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" /></svg>
          Saved
        </button>
        <button className="jf-bn-item" onClick={() => setDrawerOpen(true)}>
          <span className="jf-bn-fab">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="4" y1="21" x2="4" y2="14" /><line x1="4" y1="10" x2="4" y2="3" /><line x1="12" y1="21" x2="12" y2="12" /><line x1="12" y1="8" x2="12" y2="3" /><line x1="20" y1="21" x2="20" y2="16" /><line x1="20" y1="12" x2="20" y2="3" /></svg>
          </span>
        </button>
        <button className="jf-bn-item" onClick={() => setJobIdOpen(true)}>
          <svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="7" width="18" height="13" rx="2" /><path d="M16 3v8" /><path d="M8 3v8" /></svg>
          Job ID
        </button>
        <button className={"jf-bn-item" + (subView === "applications" ? " active" : "")} onClick={() => setSubView("applications")}>
          <svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M9 11l3 3L22 4" /><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" /></svg>
          Applications
        </button>
      </div>
    </section>
  );
}
