import React from "react";
import Header from "../components/Header.jsx";
import Footer from "../components/Footer.jsx";
import Hero from "../sections/Hero.jsx";
import StatsStrip from "../sections/StatsStrip.jsx";
import SpeedTimelines from "../sections/SpeedTimelines.jsx";
import Features from "../sections/Features.jsx";
import TwoPaths from "../sections/TwoPaths.jsx";
import Scale from "../sections/Scale.jsx";
import Stories from "../sections/Stories.jsx";
import FinalCTA from "../sections/FinalCTA.jsx";

export default function HomePage() {
  return (
    <>
      <Header />
      <main id="top">
        <Hero />
        <StatsStrip />
        <SpeedTimelines />
        <TwoPaths />
        <Features />
        <Scale />
        <Stories />
        <FinalCTA />
      </main>
      <Footer />
    </>
  );
}
