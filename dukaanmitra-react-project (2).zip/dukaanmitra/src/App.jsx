import React, { useEffect } from "react";
import { useApp } from "./context.jsx";
import HomePage from "./pages/HomePage.jsx";
import OwnerPage from "./pages/OwnerPage.jsx";
import SeekerPage from "./pages/SeekerPage.jsx";
import Toast from "./components/Toast.jsx";
import LoginChooserModal from "./components/LoginChooserModal.jsx";
import { OwnerLoginModal, OwnerSignupModal } from "./components/OwnerAuthModals.jsx";
import { SeekerLoginModal, SeekerSignupModal } from "./components/SeekerAuthModals.jsx";

const PAGE_TITLES = {
  home: "DukaanMitra — Neighbourhood Retail Hiring, Solved",
  owner: "Owner Dashboard — DukaanMitra",
  seeker: "Find a Job — DukaanMitra"
};

export default function App() {
  const { route } = useApp();

  useEffect(() => {
    document.title = PAGE_TITLES[route] || PAGE_TITLES.home;
  }, [route]);

  return (
    <>
      {route === "owner" && <OwnerPage />}
      {route === "seeker" && <SeekerPage />}
      {route !== "owner" && route !== "seeker" && <HomePage />}

      <Toast />
      <LoginChooserModal />
      <OwnerLoginModal />
      <OwnerSignupModal />
      <SeekerLoginModal />
      <SeekerSignupModal />
    </>
  );
}
