import React from "react";
import { useApp } from "../context.jsx";

export default function Footer() {
  const { resetAllData } = useApp();
  return (
    <footer>
      <div className="wrap footer-grid">
        <div>
          <div className="footer-brand">DukaanMitra</div>
          <p className="footer-desc">Neighbourhood retail hiring, solved — mobile-first, OTP-verified, and built to scale across every Indian city.</p>
        </div>
        <div className="footer-col">
          <h5>Company</h5>
          <ul><li><a href="#">About</a></li><li><a href="#">Careers</a></li><li><a href="#">Contact</a></li></ul>
        </div>
        <div className="footer-col">
          <h5>Product</h5>
          <ul><li><a href="#paths">For Shop Owners</a></li><li><a href="#paths">For Job Seekers</a></li><li><a href="#features">Features</a></li></ul>
        </div>
        <div className="footer-col">
          <h5>Legal</h5>
          <ul><li><a href="#">Privacy Policy</a></li><li><a href="#">Terms</a></li><li><a href="#">Support</a></li></ul>
        </div>
      </div>
      <div className="wrap footer-bottom">
        <span>© 2026 DukaanMitra. All rights reserved.</span>
        <span style={{ display: "flex", gap: 14, alignItems: "center" }}>
          Made for shop owners and job seekers across India.
          <button
            onClick={() => { if (window.confirm("Reset all demo data (jobs, applications, logins)? This can't be undone.")) resetAllData(); }}
            style={{ background: "none", border: "none", color: "#7C8AA0", textDecoration: "underline", cursor: "pointer", fontSize: "0.78rem", padding: 0 }}
          >
            Reset demo data
          </button>
        </span>
      </div>
    </footer>
  );
}
