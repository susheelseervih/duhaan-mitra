import React, { useState } from "react";
import { useApp } from "../context.jsx";
import { useFocusTrap } from "../useFocusTrap.js";

function initials(name) {
  return name.split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();
}

export default function SavedModal({ show, onClose, currentQuery, onOpenDetails }) {
  const { jobs, savedJobIds, toggleSaveJob, handleApplyClick, appliedJobIds, savedSearches, toggleSearchAlert, saveCurrentSearch } = useApp();
  const [tab, setTab] = useState("jobs"); // 'jobs' | 'searches'
  const containerRef = useFocusTrap(show, onClose);
  if (!show) return null;

  const savedJobs = jobs.filter((j) => savedJobIds.has(j.id));

  return (
    <div className="jf-modal-overlay show" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="jf-modal jf-saved-modal" ref={containerRef} role="dialog" aria-modal="true">
        <div style={{ padding: 26 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <h3 style={{ fontSize: "1.1rem" }}>Saved</h3>
            <button className="jf-drawer-close" onClick={onClose}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" /></svg>
            </button>
          </div>

          <div className="auth-tab-row">
            <button className={"auth-tab-btn" + (tab === "jobs" ? " active" : "")} onClick={() => setTab("jobs")} type="button">
              Saved Jobs {savedJobs.length > 0 ? `(${savedJobs.length})` : ""}
            </button>
            <button className={"auth-tab-btn" + (tab === "searches" ? " active" : "")} onClick={() => setTab("searches")} type="button">
              Saved Searches
            </button>
          </div>

          {tab === "jobs" ? (
            savedJobs.length === 0 ? (
              <div className="jf-empty-state" style={{ padding: "24px 10px" }}>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" /></svg>
                No saved jobs yet. Tap the bookmark icon on any job to save it here.
              </div>
            ) : (
              savedJobs.map((job) => {
                const salaryLabel = job.salaryType === "daily" ? `₹${job.salaryMin}–₹${job.salaryMax}/day` : `₹${job.salaryMin.toLocaleString("en-IN")}–₹${job.salaryMax.toLocaleString("en-IN")}/mo`;
                const applied = appliedJobIds.has(job.id);
                return (
                  <div className="jf-saved-item" key={job.id} style={{ alignItems: "flex-start" }}>
                    <div style={{ display: "flex", gap: 12 }}>
                      <div className="jf-shop-logo" style={{ width: 38, height: 38, fontSize: "0.8rem" }}>{initials(job.shop)}</div>
                      <div>
                        <div className="jf-saved-title">{job.title}</div>
                        <div className="jf-saved-sub">{job.shop} · {job.area}, {job.city} · {job.distanceKm} km</div>
                        <div className="jf-saved-sub" style={{ color: "var(--green)", fontWeight: 700, marginTop: 2 }}>{salaryLabel}</div>
                      </div>
                    </div>
                    <div style={{ display: "flex", flexDirection: "column", gap: 6, alignItems: "flex-end" }}>
                      <button className="btn btn-outline btn-sm" onClick={() => { onClose(); onOpenDetails(job); }}>Details</button>
                      {job.status !== "Active" && !applied ? (
                        <button className="btn btn-outline btn-sm" disabled style={{ opacity: 0.6, cursor: "not-allowed" }}>
                          {job.status === "Filled" ? "Filled" : "Closed"}
                        </button>
                      ) : (
                        <button className="btn btn-primary btn-sm" onClick={() => handleApplyClick(job.id)}>{applied ? "Applied ✓" : "Apply"}</button>
                      )}
                      <button
                        onClick={() => toggleSaveJob(job.id)}
                        style={{ background: "none", border: "none", color: "var(--ink-soft)", fontSize: "0.75rem", textDecoration: "underline", cursor: "pointer" }}
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                );
              })
            )
          ) : (
            <>
              <div>
                {savedSearches.map((s, i) => (
                  <div className="jf-saved-item" key={i}>
                    <div><div className="jf-saved-title">{s.title}</div><div className="jf-saved-sub">{s.sub}</div></div>
                    <div className={"jf-alert-toggle" + (s.alertOn ? " on" : "")} onClick={() => toggleSearchAlert(i)} />
                  </div>
                ))}
              </div>
              <button className="btn btn-outline btn-block" style={{ marginTop: 16 }} onClick={() => saveCurrentSearch(currentQuery, "All jobs near you")}>
                + Save Current Search
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
