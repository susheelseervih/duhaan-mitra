import React, { useRef } from "react";

export default function OtpStep({ heading, sentTo, onVerify, verifyLabel }) {
  const refs = [useRef(), useRef(), useRef(), useRef()];

  const handleInput = (i, e) => {
    if (e.target.value && refs[i + 1] && refs[i + 1].current) {
      refs[i + 1].current.focus();
    }
  };

  return (
    <div>
      <h3>{heading || "Enter OTP"}</h3>
      <p className="auth-sub">Sent to <strong>{sentTo}</strong></p>
      <div className="auth-otp-row">
        {refs.map((r, i) => (
          <input
            key={i}
            ref={r}
            className="auth-otp-box"
            maxLength={1}
            inputMode="numeric"
            aria-label={"OTP digit " + (i + 1) + " of 4"}
            onChange={(e) => handleInput(i, e)}
          />
        ))}
      </div>
      <button className="btn btn-primary btn-block" style={{ marginTop: 14 }} onClick={onVerify}>
        {verifyLabel || "Verify & Continue"}
      </button>
    </div>
  );
}
