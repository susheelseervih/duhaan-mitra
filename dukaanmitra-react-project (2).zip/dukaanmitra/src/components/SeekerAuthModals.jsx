import React, { useState } from "react";
import Modal from "./Modal.jsx";
import OtpStep from "./OtpStep.jsx";
import { useApp, lookupPin } from "../context.jsx";
import { languageList } from "../data.js";

export function SeekerLoginModal() {
  const { activeModal, closeModal, openModal, loginSeeker, showToast } = useApp();
  const [step, setStep] = useState("details");
  const [mobile, setMobile] = useState("");

  const close = () => { closeModal(); setStep("details"); setMobile(""); };
  const sendOtp = () => {
    if (mobile.trim().length !== 10) { showToast("Enter a valid 10-digit mobile number."); return; }
    setStep("otp");
  };
  const verify = () => { loginSeeker(mobile); setStep("details"); setMobile(""); };
  const goToSignup = () => { close(); openModal("seekerSignup"); };

  return (
    <Modal show={activeModal === "seekerLogin"} onClose={close}>
      <span className="auth-badge seeker">JOB FINDER</span>
      {step === "details" ? (
        <div>
          <div className="auth-tab-row">
            <button className="auth-tab-btn active" type="button">Log In</button>
            <button className="auth-tab-btn" type="button" onClick={goToSignup}>Sign Up</button>
          </div>
          <h3>Log in to apply</h3>
          <p className="auth-sub">Enter your registered mobile number to continue.</p>
          <div className="auth-field">
            <label>Mobile Number</label>
            <div className="auth-mobile-row">
              <span>+91</span>
              <input type="text" maxLength={10} inputMode="numeric" placeholder="98765 43210"
                value={mobile} onChange={(e) => setMobile(e.target.value)} />
            </div>
          </div>
          <button className="btn btn-primary btn-block" onClick={sendOtp}>Send OTP</button>
          <p className="auth-alt">New here? <a href="#" onClick={(e) => { e.preventDefault(); goToSignup(); }}>Sign up</a> to create your account.</p>
        </div>
      ) : (
        <OtpStep sentTo={"+91 " + mobile} onVerify={verify} verifyLabel="Verify & Apply" />
      )}
    </Modal>
  );
}

const emptyForm = {
  name: "", mobile: "", whatsapp: "", gender: "Male", dob: "",
  pin: "", city: "", state: "", area: "", address: "",
  lookingFor: "Cashier", salary: "", jobType: "Full-Time", immediateJoining: "Yes",
  categories: [], languages: ["Hindi", "English"], aadhaarNumber: "",
  aadhaarFile: "", photoFile: "", resumeFile: "", terms: false
};

export function SeekerSignupModal() {
  const { activeModal, closeModal, openModal, completeSeekerAuth, showToast } = useApp();
  const [step, setStep] = useState("form");
  const [form, setForm] = useState(emptyForm);

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const onPinChange = (e) => {
    const pin = e.target.value;
    setForm((f) => ({ ...f, pin }));
    if (pin.trim().length === 6) {
      const match = lookupPin(pin.trim());
      if (match) setForm((f) => ({ ...f, pin, city: match.city, state: match.state }));
      else showToast("Couldn't auto-detect that PIN — please fill city and state manually.");
    }
  };

  const toggleMulti = (key, value) => {
    setForm((f) => {
      const has = f[key].includes(value);
      return { ...f, [key]: has ? f[key].filter((v) => v !== value) : [...f[key], value] };
    });
  };

  const onFile = (key, label) => (e) => {
    if (e.target.files && e.target.files.length > 0) {
      setForm((f) => ({ ...f, [key]: e.target.files[0].name }));
      showToast(label + " uploaded: " + e.target.files[0].name);
    }
  };

  const close = () => { closeModal(); setStep("form"); };
  const goToLogin = () => { close(); openModal("seekerLogin"); };

  const submit = () => {
    const aadhaar = form.aadhaarNumber.replace(/\s/g, "").trim();
    if (!form.name.trim()) { showToast("Please enter your full name."); return; }
    if (form.mobile.trim().length !== 10) { showToast("Enter a valid 10-digit mobile number."); return; }
    if (!aadhaar) { showToast("Aadhaar number is required."); return; }
    if (aadhaar.length !== 12 || !/^\d+$/.test(aadhaar)) { showToast("Enter a valid 12-digit Aadhaar number."); return; }
    if (!form.terms) { showToast("Please accept the Terms and Privacy Policy to continue."); return; }
    setStep("otp");
  };

  const verify = () => {
    completeSeekerAuth({ name: form.name.trim(), mobile: form.mobile.trim() }, "Mitra account created! Welcome, " + form.name.trim() + ".");
    setForm(emptyForm);
    setStep("form");
  };

  const uploadBox = (label, fileKey, inputId, accept) => (
    <div className="flow-field">
      <label>{label}</label>
      <label
        className="signup-upload-box"
        htmlFor={inputId}
        style={form[fileKey] ? { borderColor: "var(--green)", borderStyle: "solid", color: "var(--green)" } : undefined}
      >
        {form[fileKey] ? "Selected ✓ (tap to change)" : "Tap to upload — camera, gallery, or files"}
      </label>
      <input type="file" id={inputId} accept={accept} style={{ display: "none" }} onChange={onFile(fileKey, label)} />
    </div>
  );

  return (
    <Modal show={activeModal === "seekerSignup"} onClose={close} large>
      <span className="auth-badge seeker">JOB FINDER</span>
      {step === "form" ? (
        <div>
          <h3>Create your Mitra account</h3>
          <p className="auth-sub">Takes about 2 minutes — you'll verify your mobile number at the end.</p>

          <div className="flow-section-divider" style={{ marginTop: 6 }}><h4>Basic details</h4><div className="fline" /></div>
          <div className="flow-form-grid">
            <div className="flow-field"><label>Full Name</label><input type="text" placeholder="e.g. Ravi Kumar" value={form.name} onChange={set("name")} /></div>
            <div className="flow-field">
              <label>Mobile Number</label>
              <div className="auth-mobile-row"><span>+91</span><input type="text" maxLength={10} inputMode="numeric" placeholder="98765 43210" value={form.mobile} onChange={set("mobile")} /></div>
            </div>
            <div className="flow-field full"><label>WhatsApp Number <span style={{ fontWeight: 400, color: "var(--ink-soft)" }}>(optional, if different)</span></label><input type="text" maxLength={10} inputMode="numeric" placeholder="98765 43210" value={form.whatsapp} onChange={set("whatsapp")} /></div>
          </div>

          <div className="flow-section-divider"><h4>Personal information</h4><div className="fline" /></div>
          <div className="flow-form-grid">
            <div className="flow-field">
              <label>Gender</label>
              <select value={form.gender} onChange={set("gender")}>{["Male","Female","Other"].map((g) => <option key={g}>{g}</option>)}</select>
            </div>
            <div className="flow-field"><label>Date of Birth</label><input type="date" value={form.dob} onChange={set("dob")} /></div>
            <div className="flow-field"><label>PIN Code</label><input type="text" maxLength={6} inputMode="numeric" placeholder="e.g. 560038" value={form.pin} onChange={onPinChange} /></div>
            <div className="flow-field"><label>City</label><input type="text" placeholder="Auto-fills from PIN" value={form.city} onChange={set("city")} /></div>
            <div className="flow-field"><label>State</label><input type="text" placeholder="Auto-fills from PIN" value={form.state} onChange={set("state")} /></div>
            <div className="flow-field"><label>Area / Locality</label><input type="text" placeholder="e.g. Rohini" value={form.area} onChange={set("area")} /></div>
            <div className="flow-field full"><label>Current Address</label><input type="text" placeholder="House no., street, area" value={form.address} onChange={set("address")} /></div>
          </div>

          <div className="flow-section-divider"><h4>Job preferences</h4><div className="fline" /></div>
          <div className="flow-form-grid">
            <div className="flow-field">
              <label>Looking For</label>
              <select value={form.lookingFor} onChange={set("lookingFor")}>{["Cashier","Helper","Delivery","Sales","Billing","Other"].map((o) => <option key={o}>{o}</option>)}</select>
            </div>
            <div className="flow-field"><label>Expected Salary</label><input type="text" placeholder="e.g. ₹12,000+/mo" value={form.salary} onChange={set("salary")} /></div>
            <div className="flow-field">
              <label>Job Type</label>
              <div className="flow-check-group">
                {["Full-Time", "Part-Time"].map((t) => (
                  <label key={t} className="flow-check-pill">
                    <input type="radio" name="jobType" checked={form.jobType === t} onChange={() => setForm((f) => ({ ...f, jobType: t }))} /> {t}
                  </label>
                ))}
              </div>
            </div>
            <div className="flow-field">
              <label>Immediate Joining?</label>
              <div className="flow-check-group">
                {["Yes", "No"].map((t) => (
                  <label key={t} className="flow-check-pill">
                    <input type="radio" name="immediateJoining" checked={form.immediateJoining === t} onChange={() => setForm((f) => ({ ...f, immediateJoining: t }))} /> {t}
                  </label>
                ))}
              </div>
            </div>
          </div>
          <div className="flow-field full" style={{ marginTop: 16 }}>
            <label>Preferred Shop Categories</label>
            <div className="flow-check-group" style={{ marginTop: 8 }}>
              {["Kirana Store","Jewellery Shop","Medical Store","Bakery","Mobile Shop","Supermarket","Any"].map((c) => (
                <label key={c} className="flow-check-pill">
                  <input type="checkbox" checked={form.categories.includes(c)} onChange={() => toggleMulti("categories", c)} /> {c}
                </label>
              ))}
            </div>
          </div>

          <div className="flow-section-divider"><h4>Languages known</h4><div className="fline" /></div>
          <div className="flow-check-group">
            {languageList.map((l) => (
              <label key={l} className="flow-check-pill">
                <input type="checkbox" checked={form.languages.includes(l)} onChange={() => toggleMulti("languages", l)} /> {l}
              </label>
            ))}
          </div>

          <div className="flow-section-divider"><h4>Optional documents</h4><div className="fline" /></div>
          <div className="flow-form-grid">
            <div className="flow-field"><label>Aadhaar Number</label><input type="text" maxLength={14} inputMode="numeric" placeholder="XXXX XXXX XXXX" required value={form.aadhaarNumber} onChange={set("aadhaarNumber")} /></div>
            {uploadBox("Aadhaar Upload", "aadhaarFile", "ssAadhaarFile", "image/*,.pdf")}
            {uploadBox("Passport Photo", "photoFile", "ssPhotoFile", "image/*")}
            {uploadBox("Resume (optional)", "resumeFile", "ssResumeFile", "image/*,.pdf,.doc,.docx")}
          </div>

          <label className="flow-check-pill" style={{ width: "100%", justifyContent: "flex-start", marginTop: 22, boxSizing: "border-box" }}>
            <input type="checkbox" checked={form.terms} onChange={(e) => setForm((f) => ({ ...f, terms: e.target.checked }))} /> I agree to DukaanMitra Terms and Privacy Policy.
          </label>

          <button className="btn btn-primary btn-block" style={{ marginTop: 18 }} onClick={submit}>Create Mitra Account</button>
          <p className="auth-alt">Already have an account? <a href="#" onClick={(e) => { e.preventDefault(); goToLogin(); }}>Log in</a> instead.</p>
        </div>
      ) : (
        <OtpStep heading="Verify your number" sentTo={"+91 " + form.mobile} onVerify={verify} verifyLabel="Verify & Create Account" />
      )}
    </Modal>
  );
}
