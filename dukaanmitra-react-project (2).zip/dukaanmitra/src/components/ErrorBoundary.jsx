import React from "react";
import { clearPersisted } from "../persist.js";

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, info) {
    console.error("DukaanMitra crashed:", error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{
          minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center",
          padding: 24, background: "#FCFAF5", fontFamily: "Inter, sans-serif"
        }}>
          <div style={{
            maxWidth: 420, textAlign: "center", background: "#fff", border: "1px solid #E4E0D6",
            borderRadius: 24, padding: 40
          }}>
            <div style={{ fontSize: 40, marginBottom: 16 }}>⚠️</div>
            <h2 style={{ fontFamily: "'Baloo 2', sans-serif", color: "#0A2B41", marginBottom: 10 }}>
              Something went wrong
            </h2>
            <p style={{ color: "#54626B", fontSize: "0.92rem", marginBottom: 24 }}>
              DukaanMitra hit an unexpected error. You can try reloading the page, or reset the
              demo data if the problem keeps happening.
            </p>
            <div style={{ display: "flex", gap: 10, justifyContent: "center", flexWrap: "wrap" }}>
              <button
                onClick={() => window.location.reload()}
                style={{
                  background: "#FF9933", color: "#0A2B41", border: "none", padding: "12px 22px",
                  borderRadius: 999, fontWeight: 700, cursor: "pointer"
                }}
              >
                Reload Page
              </button>
              <button
                onClick={() => { clearPersisted(); window.location.hash = "/"; window.location.reload(); }}
                style={{
                  background: "transparent", color: "#0F3D5C", border: "2px solid #0F3D5C",
                  padding: "10px 20px", borderRadius: 999, fontWeight: 700, cursor: "pointer"
                }}
              >
                Reset Demo Data
              </button>
            </div>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
