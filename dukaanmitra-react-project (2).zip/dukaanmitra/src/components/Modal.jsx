import React from "react";
import { useFocusTrap } from "../useFocusTrap.js";

export default function Modal({ show, onClose, large, children }) {
  const containerRef = useFocusTrap(show, onClose);
  if (!show) return null;
  return (
    <div
      className="auth-overlay show"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div ref={containerRef} className={"auth-modal" + (large ? " auth-modal-lg" : "")} role="dialog" aria-modal="true">
        <button className="auth-close" onClick={onClose} aria-label="Close">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
          </svg>
        </button>
        <div className="auth-modal-inner">{children}</div>
      </div>
    </div>
  );
}
