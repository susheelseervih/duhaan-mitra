import React from "react";
import Modal from "./Modal.jsx";
import { useApp } from "../context.jsx";

export default function LoginChooserModal() {
  const { activeModal, closeModal, openModal, requireSeekerAuth, requireOwnerAuth, goSeeker, goOwner } = useApp();

  const chooseSeeker = () => {
    closeModal();
    requireSeekerAuth(() => goSeeker());
  };
  const chooseOwner = () => {
    closeModal();
    requireOwnerAuth(() => goOwner("dashboard"));
  };

  return (
    <Modal show={activeModal === "loginChooser"} onClose={closeModal}>
      <h3>Log in to DukaanMitra</h3>
      <p className="auth-sub">Choose how you'd like to continue. New here? We'll set up your account in the same step.</p>

      <button className="role-choice-card" onClick={chooseSeeker}>
        <div className="role-choice-icon" style={{ background: "#FFF3E4" }}>
          <svg viewBox="0 0 24 24" fill="none" stroke="var(--saffron-dark)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" />
          </svg>
        </div>
        <div>
          <div className="role-choice-title">I'm a Job Finder</div>
          <div className="role-choice-sub">Find jobs near home and track applications</div>
        </div>
      </button>

      <button className="role-choice-card" onClick={chooseOwner}>
        <div className="role-choice-icon" style={{ background: "#E9F1F7" }}>
          <svg viewBox="0 0 24 24" fill="none" stroke="var(--navy)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M3 9l1-5h16l1 5" /><path d="M5 9v10h14V9" />
          </svg>
        </div>
        <div>
          <div className="role-choice-title">I'm a Shop Owner</div>
          <div className="role-choice-sub">Post jobs, review candidates, manage hiring</div>
        </div>
      </button>
    </Modal>
  );
}
