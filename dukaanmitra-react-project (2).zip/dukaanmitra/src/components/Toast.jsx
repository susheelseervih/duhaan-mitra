import React from "react";
import { useApp } from "../context.jsx";

export default function Toast() {
  const { toast } = useApp();
  return (
    <div className={"flow-toast" + (toast ? " show" : "")} role="status" aria-live="polite" aria-atomic="true">
      {toast && (
        <>
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M20 6L9 17l-5-5" />
          </svg>
          {toast}
        </>
      )}
    </div>
  );
}
