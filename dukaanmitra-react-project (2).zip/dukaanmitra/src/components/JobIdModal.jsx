import React, { useState } from "react";
import { useApp } from "../context.jsx";
import { useFocusTrap } from "../useFocusTrap.js";

export default function JobIdModal({ show, onClose, onViewDetails }) {
  const { jobs, handleApplyClick } = useApp();
  const [value, setValue] = useState("");
  const [result, setResult] = useState(null); // { job } | { notFound: true }
  const containerRef = useFocusTrap(show, onClose);

  if (!show) return null;

  const search = () => {
    const raw = value.trim().toUpperCase();
    if (!raw) { setResult({ error: "Please enter a Job ID." }); return; }
    const job = jobs.find((j) => j.jobId === raw);
    if (!job) { setResult({ notFound: true }); return; }
    if (job.status === "Closed") { setResult({ blocked: job, reason: "closed" }); return; }
    if (job.status === "Filled") { setResult({ blocked: job, reason: "filled" }); return; }
    if (job.lastDateISO && new Date(job.lastDateISO + "T23:59:59").getTime() < Date.now()) {
      setResult({ blocked: job, reason: "expired" });
      return;
    }
    setResult({ job });
  };

  const close = () => { setValue(""); setResult(null); onClose(); };
  const salaryLabel = (job) => job.salaryType === "daily"
    ? `₹${job.salaryMin}–₹${job.salaryMax}/day`
    : `₹${job.salaryMin.toLocaleString("en-IN")}–₹${job.salaryMax.toLocaleString("en-IN")}/mo`;

  return (
    <div className="jf-modal-overlay show" onClick={(e) => { if (e.target === e.currentTarget) close(); }}>
      <div className="jf-modal jf-jobid-modal" ref={containerRef} role="dialog" aria-modal="true">
        <div style={{ padding: 26 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
            <h3 style={{ fontSize: "1.1rem" }}>Apply with Job ID</h3>
            <button className="jf-drawer-close" onClick={close}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" /></svg>
            </button>
          </div>
          <p className="jf-jobid-hint">A shop owner shared a Job ID with you over phone or WhatsApp? Enter it below.</p>
          <div className="jf-jobid-input-row">
            <input
              type="text" placeholder="e.g. SJ240327" maxLength={12}
              value={value} onChange={(e) => setValue(e.target.value)}
              onKeyUp={(e) => { if (e.key === "Enter") search(); }}
            />
            <button className="btn btn-primary" onClick={search}>Search</button>
          </div>

          {result && result.error && <div className="jf-jobid-error">{result.error}</div>}

          {result && result.notFound && (
            <>
              <div className="jf-jobid-error">Invalid Job ID. That job may be closed, filled, or expired.</div>
              <div style={{ marginTop: 14, fontSize: "0.82rem", fontWeight: 700, color: "var(--navy-dark)" }}>Similar nearby jobs:</div>
              <div style={{ marginTop: 8 }}>
                {jobs.filter((j) => j.status === "Active").slice(0, 3).map((j) => (
                  <div className="jf-saved-item" key={j.id}>
                    <div><div className="jf-saved-title">{j.title}</div><div className="jf-saved-sub">{j.shop} · {j.distanceKm} km</div></div>
                    <button className="btn btn-outline btn-sm" onClick={() => { close(); onViewDetails(j); }}>View</button>
                  </div>
                ))}
              </div>
            </>
          )}

          {result && result.blocked && (
            <div className="jf-jobid-result">
              <div className="jf-job-title-row" style={{ marginBottom: 6 }}>
                <span className="jf-job-title">{result.blocked.title}</span>
              </div>
              <div className="jf-shop-name" style={{ marginBottom: 10 }}>{result.blocked.shop} · {result.blocked.area}, {result.blocked.city}</div>
              <div className="jf-jobid-error">
                {result.reason === "closed" && "This job has been closed by the shop owner and is no longer accepting applications."}
                {result.reason === "filled" && "This job has already been filled."}
                {result.reason === "expired" && "The application deadline for this job has passed."}
              </div>
              <button className="btn btn-outline btn-block" style={{ marginTop: 14 }} onClick={() => { close(); onViewDetails(result.blocked); }}>View Details</button>
            </div>
          )}

          {result && result.job && (
            <div className="jf-jobid-result">
              <div className="jf-job-title-row" style={{ marginBottom: 6 }}>
                <span className="jf-job-title">{result.job.title}</span>
                {result.job.verified && (
                  <span className="jf-verified-badge">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6L9 17l-5-5" /></svg>
                    Verified
                  </span>
                )}
              </div>
              <div className="jf-shop-name" style={{ marginBottom: 10 }}>{result.job.shop} · {result.job.area}, {result.job.city} · {result.job.distanceKm} km away</div>
              <div className="jf-job-salary" style={{ marginBottom: 14 }}>{salaryLabel(result.job)}</div>
              <div style={{ display: "flex", gap: 10 }}>
                <button className="btn btn-primary btn-block" onClick={() => { handleApplyClick(result.job.id); close(); }}>Apply Now</button>
                <button className="btn btn-outline btn-block" onClick={() => { close(); onViewDetails(result.job); }}>View Details</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
