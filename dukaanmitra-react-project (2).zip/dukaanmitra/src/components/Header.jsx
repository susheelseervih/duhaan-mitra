import React, { useState } from "react";
import { useApp } from "../context.jsx";

export default function Header() {
  const { openModal } = useApp();
  const [navOpen, setNavOpen] = useState(false);

  const scrollToPaths = () => {
    setNavOpen(false);
    const el = document.getElementById("paths");
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <>
      <header>
        <div className="wrap nav">
          <a href="#/" className="brand"><span>Dukaan</span><span className="dot">Mitra</span></a>
          <nav className={"nav-links" + (navOpen ? " open" : "")}>
            <a href="#speed" onClick={() => setNavOpen(false)}>How It Works</a>
            <a href="#features" onClick={() => setNavOpen(false)}>Features</a>
            <a href="#paths" onClick={() => setNavOpen(false)}>For You</a>
            <a href="#scale" onClick={() => setNavOpen(false)}>Our Scale</a>
            <a href="#stories" onClick={() => setNavOpen(false)}>Stories</a>
          </nav>
          <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
            <button className="btn btn-outline btn-sm" onClick={() => openModal("loginChooser")}>Log In</button>
            <button className="btn btn-primary btn-sm" onClick={scrollToPaths}>Get Started</button>
            <button className="menu-toggle" onClick={() => setNavOpen((o) => !o)} aria-label="Menu">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><line x1="3" y1="6" x2="21" y2="6" /><line x1="3" y1="12" x2="21" y2="12" /><line x1="3" y1="18" x2="21" y2="18" /></svg>
            </button>
          </div>
        </div>
      </header>
      <div className="awning" />
    </>
  );
}
