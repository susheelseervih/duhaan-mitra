import React from "react";
import { useApp } from "../context.jsx";

function initials(name) {
  return name.split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();
}

export default function JobCard({ job, onOpenDetails, onShare }) {
  const { savedJobIds, appliedJobIds, toggleSaveJob, handleApplyClick } = useApp();
  const saved = savedJobIds.has(job.id);
  const applied = appliedJobIds.has(job.id);
  const salaryLabel = job.salaryType === "daily"
    ? `₹${job.salaryMin}–₹${job.salaryMax}/day`
    : `₹${job.salaryMin.toLocaleString("en-IN")}–₹${job.salaryMax.toLocaleString("en-IN")}/mo`;

  return (
    <div className="jf-job-card">
      {job.urgent && (
        <span className="jf-urgent-badge">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M13 2L3 14h8l-1 8 10-12h-8z" /></svg>
          Urgent
        </span>
      )}
      <div className="jf-job-top">
        <div className="jf-shop-logo">{initials(job.shop)}</div>
        <div>
          <div className="jf-job-title-row">
            <span className="jf-job-title">{job.title}</span>
            {job.verified && (
              <span className="jf-verified-badge">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6L9 17l-5-5" /></svg>
                Verified
              </span>
            )}
          </div>
          <div className="jf-shop-name">{job.shop} · {job.area}, {job.city}</div>
          <div className="jf-jobid-tag">Job ID: {job.jobId}</div>
        </div>
      </div>
      <div className="jf-job-meta-grid">
        <span className="jf-dist-highlight">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 10c0 7-9 12-9 12s-9-5-9-12a9 9 0 0 1 18 0z" /><circle cx="12" cy="10" r="3" /></svg>
          {job.distanceKm} km · {job.travel}
        </span>
        <span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 3" /></svg>{job.hours} · {job.shift}</span>
        <span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 10v6M2 10l10-5 10 5-10 5z" /><path d="M6 12v5c3 3 9 3 12 0v-5" /></svg>{job.education === "none" ? "No education req." : job.education}</span>
        <span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /></svg>{job.vacancies} vacancy · {job.posted}</span>
      </div>
      <div className="jf-job-tags">
        {job.skills.slice(0, 3).map((s) => <span key={s} className="jf-tag">{s}</span>)}
      </div>
      <div className="jf-job-foot">
        <div>
          <div className="jf-job-salary">{salaryLabel}</div>
          <div className="jf-applicants-note">{job.applicants} applicants</div>
        </div>
        <div className="jf-job-actions">
          <button className={"jf-icon-action" + (saved ? " saved" : "")} onClick={() => toggleSaveJob(job.id)} title="Save job">
            <svg viewBox="0 0 24 24" fill={saved ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z" /></svg>
          </button>
          <button className="jf-icon-action" onClick={() => onShare(job)} title="Share via WhatsApp">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" /></svg>
          </button>
          <button className="btn btn-outline btn-sm" onClick={() => onOpenDetails(job)}>Details</button>
          <button className="btn btn-primary btn-sm" onClick={() => handleApplyClick(job.id)}>{applied ? "Applied ✓" : "Apply"}</button>
        </div>
      </div>
    </div>
  );
}
