import React from "react";
import { useApp } from "../context.jsx";
import { useFocusTrap } from "../useFocusTrap.js";

function initials(name) {
  return name.split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();
}

export default function JobDetailsModal({ job, onClose, onShare, onReport }) {
  const { savedJobIds, appliedJobIds, toggleSaveJob, handleApplyClick } = useApp();
  const containerRef = useFocusTrap(!!job, onClose);
  if (!job) return null;
  const saved = savedJobIds.has(job.id);
  const applied = appliedJobIds.has(job.id);
  const salaryLabel = job.salaryType === "daily"
    ? `₹${job.salaryMin}–₹${job.salaryMax}/day`
    : `₹${job.salaryMin.toLocaleString("en-IN")}–₹${job.salaryMax.toLocaleString("en-IN")}/mo`;
  const qrUrl = "https://api.qrserver.com/v1/create-qr-code/?size=140x140&data=" + encodeURIComponent("https://dukaanmitra.in/job/" + job.jobId);

  return (
    <div className="jf-modal-overlay show" onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="jf-modal" ref={containerRef} role="dialog" aria-modal="true">
        <div className="jf-modal-hero">
          <button className="jf-modal-close" onClick={onClose}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" /></svg>
          </button>
          <div className="jf-modal-hero-top">
            <div className="jf-modal-logo">{initials(job.shop)}</div>
            <div>
              <h2>{job.title}</h2>
              <div className="jf-modal-shop">{job.shop} {job.verified ? "· Verified Shop" : ""} · {job.category}</div>
            </div>
          </div>
          <span className="jf-modal-jobid">Job ID: {job.jobId}</span>
          {job.status !== "Active" && (
            <span className="jf-modal-jobid" style={{ marginLeft: 8, background: "rgba(255,255,255,0.2)" }}>
              {job.status === "Filled" ? "Filled" : "Closed"}
            </span>
          )}
        </div>
        <div className="jf-modal-body">
          <div className="jf-modal-info-grid">
            <div className="jf-modal-info-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="1" x2="12" y2="23" /><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" /></svg><div><div className="jf-modal-info-label">Salary</div><div className="jf-modal-info-value">{salaryLabel}</div></div></div>
            <div className="jf-modal-info-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 3" /></svg><div><div className="jf-modal-info-label">Working Hours</div><div className="jf-modal-info-value">{job.hours} · {job.shift}</div></div></div>
            <div className="jf-modal-info-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" /><line x1="16" y1="2" x2="16" y2="6" /><line x1="8" y1="2" x2="8" y2="6" /></svg><div><div className="jf-modal-info-label">Weekly Off</div><div className="jf-modal-info-value">{job.weeklyOff}</div></div></div>
            <div className="jf-modal-info-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /></svg><div><div className="jf-modal-info-label">Vacancies</div><div className="jf-modal-info-value">{job.vacancies} open</div></div></div>
            <div className="jf-modal-info-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 10c0 7-9 12-9 12s-9-5-9-12a9 9 0 0 1 18 0z" /><circle cx="12" cy="10" r="3" /></svg><div><div className="jf-modal-info-label">Distance</div><div className="jf-modal-info-value">{job.distanceKm} km · {job.travel}</div></div></div>
            <div className="jf-modal-info-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" /><line x1="16" y1="2" x2="16" y2="6" /><line x1="8" y1="2" x2="8" y2="6" /><line x1="3" y1="10" x2="21" y2="10" /></svg><div><div className="jf-modal-info-label">Last Date to Apply</div><div className="jf-modal-info-value">{job.lastDate}</div></div></div>
          </div>

          <div className="jf-modal-map">
            <div className="jf-map-pin" style={{ top: "55%", left: "45%" }}><div className="jf-map-pin-dot"><span>📍</span></div></div>
          </div>

          <div className="jf-modal-section"><h4>About this role</h4><p>{job.description}</p></div>
          <div className="jf-modal-section">
            <h4>Responsibilities</h4>
            <ul>{job.responsibilities.map((r) => (
              <li key={r}><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M20 6L9 17l-5-5" /></svg>{r}</li>
            ))}</ul>
          </div>
          <div className="jf-modal-section"><h4>Skills required</h4><div className="jf-job-tags">{job.skills.map((s) => <span key={s} className="jf-tag">{s}</span>)}</div></div>
          <div className="jf-modal-section"><h4>Benefits</h4><div className="jf-job-tags">{job.benefits.map((b) => <span key={b} className="jf-tag">{b}</span>)}</div></div>
          <div className="jf-modal-section"><h4>Documents required</h4><div className="jf-job-tags">{job.documents.map((d) => <span key={d} className="jf-tag">{d}</span>)}</div></div>

          <div className="jf-qr-row">
            <img src={qrUrl} alt={"QR code for " + job.jobId} />
            <div className="jf-qr-text"><strong>Scan to open this job</strong>Share this QR on posters, WhatsApp Status, or visiting cards.</div>
          </div>

          <div className="jf-modal-actions">
            {job.status !== "Active" && !applied ? (
              <button className="btn btn-outline" disabled style={{ opacity: 0.6, cursor: "not-allowed" }}>
                {job.status === "Filled" ? "Position Filled" : "No Longer Accepting Applications"}
              </button>
            ) : (
              <button className="btn btn-primary" onClick={() => { handleApplyClick(job.id); onClose(); }}>{applied ? "Applied ✓" : "Apply Now"}</button>
            )}
            <button className="btn btn-outline" onClick={() => toggleSaveJob(job.id)}>{saved ? "Saved ✓" : "Save Job"}</button>
            <button className="btn btn-outline" onClick={() => onShare(job)}>Share</button>
            <button className="btn btn-outline" onClick={onReport}>Report Job</button>
          </div>
        </div>
      </div>
    </div>
  );
}
