import React, { useState } from "react";
import Modal from "./Modal.jsx";
import OtpStep from "./OtpStep.jsx";
import { useApp, lookupPin } from "../context.jsx";

export function OwnerLoginModal() {
  const { activeModal, closeModal, openModal, loginOwner, showToast } = useApp();
  const [step, setStep] = useState("details"); // 'details' | 'otp'
  const [mobile, setMobile] = useState("");

  const close = () => { closeModal(); setStep("details"); setMobile(""); };

  const sendOtp = () => {
    if (mobile.trim().length !== 10) { showToast("Enter a valid 10-digit mobile number."); return; }
    setStep("otp");
  };
  const verify = () => { loginOwner(mobile); setStep("details"); setMobile(""); };
  const goToSignup = () => { close(); openModal("ownerSignup"); };

  return (
    <Modal show={activeModal === "ownerLogin"} onClose={close}>
      <span className="auth-badge owner">SHOP OWNER</span>
      {step === "details" ? (
        <div>
          <div className="auth-tab-row">
            <button className="auth-tab-btn active" type="button">Log In</button>
            <button className="auth-tab-btn" type="button" onClick={goToSignup}>Sign Up</button>
          </div>
          <h3>Log in to post a job</h3>
          <p className="auth-sub">Enter your registered mobile number to continue.</p>
          <div className="auth-field">
            <label>Mobile Number</label>
            <div className="auth-mobile-row">
              <span>+91</span>
              <input type="text" maxLength={10} inputMode="numeric" placeholder="98765 43210"
                value={mobile} onChange={(e) => setMobile(e.target.value)} />
            </div>
          </div>
          <button className="btn btn-primary btn-block" onClick={sendOtp}>Send OTP</button>
          <p className="auth-alt">New here? <a href="#" onClick={(e) => { e.preventDefault(); goToSignup(); }}>Sign up</a> to create your account.</p>
        </div>
      ) : (
        <OtpStep sentTo={"+91 " + mobile} onVerify={verify} verifyLabel="Verify & Continue" />
      )}
    </Modal>
  );
}

export function OwnerSignupModal() {
  const { activeModal, closeModal, openModal, completeOwnerAuth, showToast, goOwner } = useApp();
  const [step, setStep] = useState("form"); // 'form' | 'otp'
  const [form, setForm] = useState({
    name: "", mobile: "", email: "", shop: "", category: "Kirana Store",
    pin: "", city: "", state: "", area: "", address: "", terms: false
  });

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const onPinChange = (e) => {
    const pin = e.target.value;
    setForm((f) => ({ ...f, pin }));
    if (pin.trim().length === 6) {
      const match = lookupPin(pin.trim());
      if (match) setForm((f) => ({ ...f, pin, city: match.city, state: match.state }));
      else showToast("Couldn't auto-detect that PIN — please fill city and state manually.");
    }
  };

  const close = () => { closeModal(); setStep("form"); };
  const goToLogin = () => { close(); openModal("ownerLogin"); };

  const submit = () => {
    if (!form.name.trim() || !form.shop.trim()) { showToast("Please enter your name and shop name."); return; }
    if (form.mobile.trim().length !== 10) { showToast("Enter a valid 10-digit mobile number."); return; }
    if (!form.terms) { showToast("Please accept the Terms and Privacy Policy to continue."); return; }
    setStep("otp");
  };

  const verify = () => {
    completeOwnerAuth({ name: form.name.trim(), shop: form.shop.trim() });
    showToast("Dukaan account created! Welcome, " + form.name.trim() + ".");
    goOwner("postForm");
    setStep("form");
  };

  return (
    <Modal show={activeModal === "ownerSignup"} onClose={close} large>
      <span className="auth-badge owner">SHOP OWNER</span>
      {step === "form" ? (
        <div>
          <h3>Create your Dukaan account</h3>
          <p className="auth-sub">Takes about 2 minutes — you'll verify your mobile number at the end.</p>

          <div className="flow-section-divider" style={{ marginTop: 6 }}><h4>Basic details</h4><div className="fline" /></div>
          <div className="flow-form-grid">
            <div className="flow-field"><label>Full Name</label><input type="text" placeholder="e.g. Ramesh Sharma" value={form.name} onChange={set("name")} /></div>
            <div className="flow-field">
              <label>Mobile Number</label>
              <div className="auth-mobile-row"><span>+91</span><input type="text" maxLength={10} inputMode="numeric" placeholder="98765 43210" value={form.mobile} onChange={set("mobile")} /></div>
            </div>
            <div className="flow-field full"><label>Email <span style={{ fontWeight: 400, color: "var(--ink-soft)" }}>(optional)</span></label><input type="text" placeholder="owner@example.com" value={form.email} onChange={set("email")} /></div>
          </div>

          <div className="flow-section-divider"><h4>Shop information</h4><div className="fline" /></div>
          <div className="flow-form-grid">
            <div className="flow-field"><label>Shop Name</label><input type="text" placeholder="e.g. ABC Kirana Store" value={form.shop} onChange={set("shop")} /></div>
            <div className="flow-field">
              <label>Shop Category</label>
              <select value={form.category} onChange={set("category")}>
                {["Kirana Store","Jewellery Shop","Fancy Store","Hardware Store","Medical Store","Bakery","Mobile Shop","Textile Shop","Electronics Shop","Supermarket","Boutique","Other"].map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div className="flow-field"><label>PIN Code</label><input type="text" maxLength={6} inputMode="numeric" placeholder="e.g. 560038" value={form.pin} onChange={onPinChange} /></div>
            <div className="flow-field"><label>City</label><input type="text" placeholder="Auto-fills from PIN" value={form.city} onChange={set("city")} /></div>
            <div className="flow-field"><label>State</label><input type="text" placeholder="Auto-fills from PIN" value={form.state} onChange={set("state")} /></div>
            <div className="flow-field"><label>Area / Locality</label><input type="text" placeholder="e.g. Jayanagar" value={form.area} onChange={set("area")} /></div>
            <div className="flow-field full"><label>Shop Address</label><input type="text" placeholder="Shop no., street, landmark" value={form.address} onChange={set("address")} /></div>
          </div>

          <label className="flow-check-pill" style={{ width: "100%", justifyContent: "flex-start", marginTop: 22, boxSizing: "border-box" }}>
            <input type="checkbox" checked={form.terms} onChange={(e) => setForm((f) => ({ ...f, terms: e.target.checked }))} /> I agree to DukaanMitra Terms and Privacy Policy.
          </label>

          <button className="btn btn-primary btn-block" style={{ marginTop: 18 }} onClick={submit}>Create Dukaan Account</button>
          <p className="auth-alt">Already have an account? <a href="#" onClick={(e) => { e.preventDefault(); goToLogin(); }}>Log in</a> instead.</p>
        </div>
      ) : (
        <OtpStep heading="Verify your number" sentTo={"+91 " + form.mobile} onVerify={verify} verifyLabel="Verify & Create Account" />
      )}
    </Modal>
  );
}
