import React from "react";
import { categoryList, skillList, benefitList, languageList } from "../data.js";
import { useFocusTrap } from "../useFocusTrap.js";

const filterGroups = [
  { key: "distance", label: "Distance Radius", type: "single", options: [["1", "Within 1 km"], ["3", "Within 3 km"], ["5", "Within 5 km"], ["10", "Within 10 km"], ["20", "Within 20 km"], ["any", "Anywhere in the City"]] },
  { key: "categories", label: "Shop Category", type: "multi", options: categoryList.map((c) => [c, c]) },
  { key: "salary", label: "Salary Range", type: "single", options: [["5-10", "₹5,000–₹10,000"], ["10-15", "₹10,000–₹15,000"], ["15-20", "₹15,000–₹20,000"], ["20-30", "₹20,000–₹30,000"], ["30-50", "₹30,000–₹50,000"], ["50+", "₹50,000+"], ["any", "Any Salary"]] },
  { key: "salaryType", label: "Salary Type", type: "single", options: [["any", "Any"], ["negotiable", "Negotiable"], ["daily", "Daily Wage"], ["weekly", "Weekly Salary"], ["monthly", "Monthly Salary"]] },
  { key: "experience", label: "Experience", type: "single", options: [["any", "Any"], ["fresher", "Fresher"], ["0-1", "0–1 Year"], ["1-2", "1–2 Years"], ["2-5", "2–5 Years"], ["5+", "5+ Years"]] },
  { key: "employmentTypes", label: "Employment Type", type: "multi", options: [["Full-Time", "Full-Time"], ["Part-Time", "Part-Time"], ["Internship", "Internship"], ["Temporary", "Temporary"], ["Contract", "Contract"], ["Weekend", "Weekend Jobs"], ["Seasonal", "Festival Seasonal"]] },
  { key: "shifts", label: "Shift", type: "multi", options: [["Morning", "Morning"], ["Afternoon", "Afternoon"], ["Evening", "Evening"], ["Night", "Night"], ["Flexible", "Flexible"]] },
  { key: "gender", label: "Gender Preference", type: "single", options: [["any", "All Jobs"], ["male", "Male Preferred"], ["female", "Female Preferred"], ["none", "No Preference"]] },
  { key: "education", label: "Education", type: "single", options: [["any", "Any Qualification"], ["none", "No Education Required"], ["8th", "8th Pass"], ["10th", "10th Pass"], ["12th", "12th Pass / PUC"], ["diploma", "Diploma"], ["graduate", "Graduate"], ["postgrad", "Post Graduate"]] },
  { key: "languages", label: "Languages", type: "multi", options: languageList.map((l) => [l, l]) },
  { key: "skills", label: "Skills", type: "multi", options: skillList.map((s) => [s, s]) },
  { key: "benefits", label: "Benefits", type: "multi", options: benefitList.map((b) => [b, b]) }
];

export default function FilterDrawer({ open, onClose, filters, setFilters, onApply, onClear }) {
  const containerRef = useFocusTrap(open, onClose);

  const toggleOption = (key, value, type) => {
    setFilters((prev) => {
      if (type === "single") {
        return { ...prev, [key]: prev[key] === value ? "any" : value };
      }
      const set = new Set(prev[key]);
      if (set.has(value)) set.delete(value); else set.add(value);
      return { ...prev, [key]: set };
    });
  };

  return (
    <>
      <div className={"jf-drawer-overlay" + (open ? " show" : "")} onClick={onClose} />
      <div className={"jf-drawer" + (open ? " show" : "")} ref={containerRef} role="dialog" aria-modal="true" aria-hidden={!open}>
        <div className="jf-drawer-head">
          <h3>All Filters</h3>
          <button className="jf-drawer-close" onClick={onClose} aria-label="Close filters">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" /></svg>
          </button>
        </div>
        <div className="jf-drawer-body">
          {filterGroups.map((g) => (
            <div className="jf-filter-group" key={g.key}>
              <h4>{g.label}</h4>
              <div className="jf-filter-options">
                {g.options.map(([v, l]) => {
                  const active = g.type === "single" ? filters[g.key] === v : filters[g.key].has(v);
                  return (
                    <button key={v} className={"jf-opt-pill" + (active ? " active" : "")} onClick={() => toggleOption(g.key, v, g.type)}>
                      {l}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
        <div className="jf-drawer-foot">
          <button className="btn btn-outline btn-block" onClick={onClear}>Clear All</button>
          <button className="btn btn-primary btn-block" onClick={onApply}>Show Results</button>
        </div>
      </div>
    </>
  );
}

export const defaultFilters = () => ({
  distance: "any", categories: new Set(), salary: "any", salaryType: "any",
  experience: "any", employmentTypes: new Set(), shifts: new Set(), gender: "any",
  education: "any", languages: new Set(), skills: new Set(), benefits: new Set(),
  urgentOnly: false, verifiedOnly: false, freshersOnly: false, walkinOnly: false
});
