import React from "react";

const cityRows = [
  ["Delhi NCR", 92], ["Maharashtra", 81], ["Karnataka", 74], ["Tamil Nadu", 63], ["Telangana", 55]
];

export default function Scale() {
  return (
    <section id="scale" className="bg-alt">
      <div className="wrap scale-grid">
        <div>
          <div className="section-head left">
            <span className="kicker">Built to scale</span>
            <h2>Designed for millions of users across India</h2>
            <p>From a single kirana store in Rohini to lakhs of shops nationwide, the same platform holds up.</p>
          </div>
          <div className="scale-list">
            <div className="scale-item">
              <div className="scale-item-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 10c0 7-9 12-9 12s-9-5-9-12a9 9 0 0 1 18 0z" /><circle cx="12" cy="10" r="3" /></svg></div>
              <div><h4>City by city rollout</h4><p>New locations onboard with local category defaults and language support, without a platform rebuild.</p></div>
            </div>
            <div className="scale-item">
              <div className="scale-item-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="7" height="9" /><rect x="14" y="3" width="7" height="5" /><rect x="14" y="12" width="7" height="9" /><rect x="3" y="16" width="7" height="5" /></svg></div>
              <div><h4>Built for peak load</h4><p>Job search and application flows are lightweight by design, so they hold up on slower mobile networks at scale.</p></div>
            </div>
            <div className="scale-item">
              <div className="scale-item-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2l9 4.5v6c0 5-3.5 8-9 9.5-5.5-1.5-9-4.5-9-9.5v-6z" /><path d="M9 12l2 2 4-4" /></svg></div>
              <div><h4>Trust systems that scale with volume</h4><p>Aadhaar checks, duplicate phone detection, and fake job flags run automatically as the user base grows.</p></div>
            </div>
          </div>
        </div>
        <div className="scale-visual">
          <h4 style={{ marginBottom: 18, fontSize: "1rem" }}>Where DukaanMitra is growing fastest</h4>
          {cityRows.map(([name, pct]) => (
            <div className="india-bar-row" key={name}>
              <span className="india-bar-label">{name}</span>
              <div className="india-bar-track"><div className="india-bar-fill" style={{ width: pct + "%" }} /></div>
              <span className="india-bar-val">{pct}%</span>
            </div>
          ))}
          <p style={{ fontSize: "0.76rem", color: "var(--ink-soft)", marginTop: 14 }}>Shop sign-up growth relative to Delhi NCR, trailing 90 days.</p>
        </div>
      </div>
    </section>
  );
}
