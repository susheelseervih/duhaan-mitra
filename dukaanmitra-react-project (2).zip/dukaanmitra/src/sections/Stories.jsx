import React from "react";

const stories = [
  { quote: "I posted a job during lunch break and had two shortlisted candidates before closing time.", initials: "RM", name: "Rekha Mehta", role: "Owner, Mehta Jewellers, Pune" },
  { quote: "I found a bakery job four minutes' walk from my house. Applied on the bus, heard back the same evening.", initials: "SK", name: "Suresh Kumar", role: "Job seeker, Chennai" },
  { quote: "The match percentage genuinely saved me time — the top candidate was exactly who I ended up hiring.", initials: "AP", name: "Anil Patil", role: "Owner, Patil Hardware, Nagpur" }
];

export default function Stories() {
  return (
    <section id="stories">
      <div className="wrap">
        <div className="section-head">
          <span className="kicker">From the community</span>
          <h2>Real hiring, real speed</h2>
        </div>
        <div className="story-grid">
          {stories.map((s) => (
            <div className="story-card" key={s.name}>
              <p className="story-quote">{s.quote}</p>
              <div className="story-who">
                <div className="story-avatar">{s.initials}</div>
                <div><div className="story-name">{s.name}</div><div className="story-role">{s.role}</div></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
