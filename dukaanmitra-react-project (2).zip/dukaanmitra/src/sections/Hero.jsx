import React from "react";
import { useApp } from "../context.jsx";

export default function Hero() {
  const { goSeeker, requireOwnerAuth, goOwner } = useApp();
  const onHire = () => requireOwnerAuth(() => goOwner("postForm"));

  return (
    <section className="hero">
      <div className="wrap hero-grid">
        <div>
          <span className="hero-eyebrow">🇮🇳 Built for India's neighbourhood retail economy</span>
          <h1>Hiring for the shop next door, made <em>instant</em>.</h1>
          <p className="sub">Job seekers find work near home in under 60 seconds. Shop owners post a job in under 2 minutes. All through a phone number and an OTP.</p>
          <div className="hero-actions">
            <button className="btn btn-primary" onClick={goSeeker}>Find a Job — I'm Looking</button>
            <button className="btn btn-outline" onClick={onHire}>Post a Job — I'm Hiring</button>
          </div>
          <div className="trust-row">
            <span className="badge"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M20 6L9 17l-5-5" /></svg>Aadhaar-verified workers</span>
            <span className="badge"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M20 6L9 17l-5-5" /></svg>Mobile OTP only, no passwords</span>
            <span className="badge"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M20 6L9 17l-5-5" /></svg>WhatsApp-native updates</span>
          </div>
        </div>
        <div className="hero-visual">
          <div className="float-chip one"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M20 6L9 17l-5-5" /></svg>OTP verified</div>
          <div className="phone-mock">
            <div className="phone-screen">
              <div className="phone-notch" />
              <div className="phone-content">
                <div className="phone-app-name">Dukaan<span>Mitra</span></div>
                <div className="otp-mock-label">Enter OTP sent to +91 98765 43210</div>
                <div className="otp-mock-row">
                  <div className="otp-mock-box">4</div><div className="otp-mock-box">7</div><div className="otp-mock-box">2</div><div className="otp-mock-box">9</div>
                </div>
                <div className="phone-map"><div className="phone-pin a" /><div className="phone-pin b" /></div>
                <div className="phone-job-card">
                  <div className="phone-job-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 9l1-5h16l1 5" /><path d="M5 9v10h14V9" /></svg></div>
                  <div>
                    <div className="phone-job-title">Counter Assistant</div>
                    <div className="phone-job-sub">1.2 km away · ₹12,000–15,000/mo</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="float-chip two"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M20 6L9 17l-5-5" /></svg>1.2 km away</div>
        </div>
      </div>
    </section>
  );
}
