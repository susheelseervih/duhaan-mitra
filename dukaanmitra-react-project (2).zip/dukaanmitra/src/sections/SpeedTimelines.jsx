import React from "react";

const seekerSteps = [
  { title: "Log in with mobile OTP", desc: "No form, no password to remember.", mark: "~10 sec" },
  { title: "Location auto-detected", desc: "Jobs sorted by distance from home instantly.", mark: "~5 sec" },
  { title: "Scan matched jobs", desc: "Salary, timing, and distance shown up front.", mark: "~30 sec" },
  { title: "One-tap apply", desc: "Application sent, confirmation shown immediately.", mark: "~10 sec", final: true }
];

const ownerSteps = [
  { title: "Log in with mobile OTP", desc: "Shop profile loads automatically after first setup.", mark: "~15 sec" },
  { title: "Fill role, salary, timing", desc: "Pre-filled category defaults speed this up further.", mark: "~60 sec" },
  { title: "Tap required skills", desc: "Checkboxes, not typing — billing, cleaning, delivery and more.", mark: "~20 sec" },
  { title: "Publish, go live instantly", desc: "Visible to nearby job seekers within seconds.", mark: "~15 sec", final: true }
];

function Timeline({ steps }) {
  return (
    <div className="timeline">
      {steps.map((s, i) => (
        <div className="t-step" key={i}>
          <div className="t-dot">{s.final ? "✓" : i + 1}</div>
          <div className="t-title">{s.title}</div>
          <div className="t-desc">{s.desc}</div>
          <div className="t-mark">{s.mark}</div>
        </div>
      ))}
    </div>
  );
}

export default function SpeedTimelines() {
  return (
    <section id="speed">
      <div className="wrap">
        <div className="section-head">
          <span className="kicker">The core promise</span>
          <h2>Built for speed, not paperwork</h2>
          <p>Every screen is designed around one question: what's the fastest path to a hire, or a job?</p>
        </div>
        <div className="speed-wrap">
          <div className="speed-col">
            <div className="speed-col-head">
              <h3>Job seeker, start to apply</h3>
              <div className="speed-time">&lt;60s<span>total time</span></div>
            </div>
            <Timeline steps={seekerSteps} />
          </div>
          <div className="speed-col">
            <div className="speed-col-head">
              <h3>Shop owner, start to live job</h3>
              <div className="speed-time">&lt;2min<span>total time</span></div>
            </div>
            <Timeline steps={ownerSteps} />
          </div>
        </div>
      </div>
    </section>
  );
}
