import React from "react";
import { useApp } from "../context.jsx";

export default function FinalCTA() {
  const { goSeeker, requireOwnerAuth, goOwner } = useApp();
  const onPostJob = () => requireOwnerAuth(() => goOwner("postForm"));

  return (
    <section style={{ paddingTop: 0 }}>
      <div className="wrap">
        <div className="final-cta">
          <h3>Ready to hire in minutes, or find work near home?</h3>
          <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
            <button className="btn btn-ghost-dark" onClick={goSeeker}>Find a Job</button>
            <button className="btn btn-outline" style={{ borderColor: "var(--navy-dark)", color: "var(--navy-dark)" }} onClick={onPostJob}>Post a Job</button>
          </div>
        </div>
      </div>
    </section>
  );
}
