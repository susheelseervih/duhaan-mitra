import React from "react";
import { useApp } from "../context.jsx";

export default function TwoPaths() {
  const { goSeeker, requireOwnerAuth, goOwner } = useApp();
  const onHire = () => requireOwnerAuth(() => goOwner("postForm"));

  return (
    <section id="paths">
      <div className="wrap">
        <div className="section-head">
          <span className="kicker">Choose your path</span>
          <h2>One platform, two very different journeys</h2>
        </div>
        <div className="path-grid">
          <div className="path-card seeker">
            <h3>For Job Seekers</h3>
            <p style={{ fontSize: "0.95rem", color: "#4A3417" }}>Find work close to home, apply in one tap, and track every application in one place.</p>
            <ul className="path-list">
              <li><svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round"><path d="M20 6L9 17l-5-5" /></svg>Find a matching job in under 60 seconds</li>
              <li><svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round"><path d="M20 6L9 17l-5-5" /></svg>Filter by distance, salary, and shift</li>
              <li><svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round"><path d="M20 6L9 17l-5-5" /></svg>One-tap apply, instant confirmation</li>
              <li><svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round"><path d="M20 6L9 17l-5-5" /></svg>SMS &amp; WhatsApp updates at every stage</li>
            </ul>
            <button className="btn btn-ghost-dark" style={{ marginTop: 8 }} onClick={goSeeker}>Find a Job — I'm Looking</button>
          </div>
          <div className="path-card owner">
            <h3>For Shop Owners</h3>
            <p style={{ color: "#C9D8E2", fontSize: "0.95rem" }}>Post a role, review AI-ranked candidates, and hire — without leaving WhatsApp for long.</p>
            <ul className="path-list">
              <li><svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round"><path d="M20 6L9 17l-5-5" /></svg>Post a job in under 2 minutes</li>
              <li><svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round"><path d="M20 6L9 17l-5-5" /></svg>AI-ranked applicants by match %</li>
              <li><svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round"><path d="M20 6L9 17l-5-5" /></svg>Call or WhatsApp candidates directly</li>
              <li><svg viewBox="0 0 24 24" fill="none" strokeWidth="2" strokeLinecap="round"><path d="M20 6L9 17l-5-5" /></svg>Track shortlisted, interview, and hired stages</li>
            </ul>
            <button className="btn btn-primary" style={{ marginTop: 8 }} onClick={onHire}>Post a Job — I'm Hiring</button>
          </div>
        </div>
      </div>
    </section>
  );
}
