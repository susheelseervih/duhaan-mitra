import React from "react";

export default function Features() {
  return (
    <section id="features" className="bg-alt">
      <div className="wrap">
        <div className="section-head">
          <span className="kicker">What's under the hood</span>
          <h2>Indian UX patterns, built in from day one</h2>
          <p>Not a global hiring tool retrofitted for India — designed around how this country's shopkeepers and job seekers already communicate.</p>
        </div>
        <div className="feature-grid">
          <div className="feature-card">
            <div className="feature-icon" style={{ "--fi-bg": "#E9F1F7", "--fi-color": "#0F3D5C" }}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 10c0 7-9 12-9 12s-9-5-9-12a9 9 0 0 1 18 0z" /><circle cx="12" cy="10" r="3" /></svg>
            </div>
            <h4>Location-first matching</h4>
            <p>Every listing and every applicant is ranked by real distance, the same instinct behind Swiggy and Zomato's local matching.</p>
            <div className="mini-mock"><div className="phone-map" style={{ marginBottom: 0, height: 90 }}><div className="phone-pin a" /><div className="phone-pin b" /></div></div>
          </div>

          <div className="feature-card">
            <div className="feature-icon" style={{ "--fi-bg": "#E4F9EA", "--fi-color": "#1FAE55" }}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z" /></svg>
            </div>
            <h4>WhatsApp-native communication</h4>
            <p>Owners and candidates connect where they already talk — one tap opens a pre-filled WhatsApp message, no app-switching guesswork.</p>
            <div className="mini-mock">
              <div className="chat-bubble">Hi, we received your application for Sales Assistant. Interview tomorrow, 10 AM?</div>
              <div className="chat-time">Delivered</div>
            </div>
          </div>

          <div className="feature-card">
            <div className="feature-icon" style={{ "--fi-bg": "#F1E7F6", "--fi-color": "#7A3E9D" }}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3" /><path d="M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1" /></svg>
            </div>
            <h4>AI-based candidate ranking</h4>
            <p>Match percentage computed from distance, skills, experience, availability, language, salary fit, and category overlap.</p>
            <div className="mini-mock">
              <div className="match-mini"><span className="match-mini-name">Ravi Kumar</span><span className="match-mini-pct">94% Match</span></div>
              <div className="match-mini"><span className="match-mini-name">Sushma Rani</span><span className="match-mini-pct">89% Match</span></div>
            </div>
          </div>

          <div className="feature-card">
            <div className="feature-icon" style={{ "--fi-bg": "#FDF3D9", "--fi-color": "#E6A100" }}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2l9 4.5v6c0 5-3.5 8-9 9.5-5.5-1.5-9-4.5-9-9.5v-6z" /><path d="M9 12l2 2 4-4" /></svg>
            </div>
            <h4>Aadhaar-backed trust</h4>
            <p>Workers upload Aadhaar for identity verification; shop owners get a verified badge after GST and document checks.</p>
            <div className="mini-mock">
              <div className="verify-row"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M20 6L9 17l-5-5" /></svg>Aadhaar verified</div>
              <div className="verify-row"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M20 6L9 17l-5-5" /></svg>Mobile OTP confirmed</div>
              <div className="verify-row"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M20 6L9 17l-5-5" /></svg>Duplicate phone check passed</div>
            </div>
          </div>

          <div className="feature-card">
            <div className="feature-icon" style={{ "--fi-bg": "#FBE4EC", "--fi-color": "#D6336C" }}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="5" y="2" width="14" height="20" rx="2" /><line x1="12" y1="18" x2="12.01" y2="18" /></svg>
            </div>
            <h4>Mobile-first, every screen</h4>
            <p>Designed for a single-hand phone flow first — filters, forms, and applying all work smoothly on a basic smartphone connection.</p>
            <div className="mini-mock" style={{ display: "flex", justifyContent: "center" }}>
              <div style={{ width: 60, height: 100, border: "3px solid var(--navy-dark)", borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="var(--navy)" strokeWidth="2" strokeLinecap="round"><path d="M20 6L9 17l-5-5" /></svg>
              </div>
            </div>
          </div>

          <div className="feature-card">
            <div className="feature-icon" style={{ "--fi-bg": "#E3F2F6", "--fi-color": "#1E88A8" }}>
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="4" y1="21" x2="4" y2="14" /><line x1="4" y1="10" x2="4" y2="3" /><line x1="12" y1="21" x2="12" y2="12" /><line x1="12" y1="8" x2="12" y2="3" /><line x1="20" y1="21" x2="20" y2="16" /><line x1="20" y1="12" x2="20" y2="3" /></svg>
            </div>
            <h4>Filters that match how people think</h4>
            <p>Distance radius, salary floor, fresher-friendly, shift timing — the filters job seekers and owners actually reach for.</p>
            <div className="mini-mock" style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
              <span style={{ background: "var(--white)", border: "1px solid var(--line)", padding: "5px 10px", borderRadius: 999, fontSize: "0.72rem", fontWeight: 600 }}>5 km</span>
              <span style={{ background: "var(--white)", border: "1px solid var(--line)", padding: "5px 10px", borderRadius: 999, fontSize: "0.72rem", fontWeight: 600 }}>₹12,000+</span>
              <span style={{ background: "var(--white)", border: "1px solid var(--line)", padding: "5px 10px", borderRadius: 999, fontSize: "0.72rem", fontWeight: 600 }}>Fresher OK</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
