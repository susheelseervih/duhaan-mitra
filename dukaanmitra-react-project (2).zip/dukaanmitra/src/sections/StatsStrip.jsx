import React from "react";

export default function StatsStrip() {
  return (
    <section className="bg-dark" style={{ padding: "44px 0" }}>
      <div className="wrap stat-strip">
        <div><strong>12,400+</strong><span>Shops hiring</span></div>
        <div><strong>38,000+</strong><span>Workers registered</span></div>
        <div><strong>42</strong><span>Cities live</span></div>
        <div><strong>&lt;60 sec</strong><span>Median time to first job match</span></div>
      </div>
    </section>
  );
}
