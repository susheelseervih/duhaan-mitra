import { useEffect, useState, useCallback } from "react";

// Simple hash-based router: #/ , #/owner , #/seeker
function readHash() {
  const hash = window.location.hash.replace(/^#\/?/, "");
  return hash || "home";
}

export function useHashRoute() {
  const [route, setRouteState] = useState(readHash());

  useEffect(() => {
    const onHashChange = () => setRouteState(readHash());
    window.addEventListener("hashchange", onHashChange);
    return () => window.removeEventListener("hashchange", onHashChange);
  }, []);

  const setRoute = useCallback((next) => {
    window.location.hash = "/" + next;
    setRouteState(next);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  return [route, setRoute];
}
