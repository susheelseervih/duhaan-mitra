const STORAGE_KEY = "dukaanmitra_state_v1";

function isPlainObject(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}

// Defensively validate every field's *type*, not just its presence. A corrupted,
// hand-edited, or stale-schema localStorage value must never crash module
// evaluation — that happens before React mounts, so no ErrorBoundary can help.
function sanitize(raw) {
  if (!isPlainObject(raw)) return null;
  const safe = {};
  if (Array.isArray(raw.jobs)) safe.jobs = raw.jobs;
  if (Array.isArray(raw.applications)) safe.applications = raw.applications;
  if (Array.isArray(raw.savedJobIds)) safe.savedJobIds = raw.savedJobIds;
  if (Array.isArray(raw.appliedJobIds)) safe.appliedJobIds = raw.appliedJobIds;
  if (Array.isArray(raw.ownerJobIds)) safe.ownerJobIds = raw.ownerJobIds;
  if (Array.isArray(raw.savedSearches)) safe.savedSearches = raw.savedSearches;
  if (isPlainObject(raw.ownerProfile)) safe.ownerProfile = raw.ownerProfile;
  if (isPlainObject(raw.seekerProfile)) safe.seekerProfile = raw.seekerProfile;
  if (typeof raw.ownerLoggedIn === "boolean") safe.ownerLoggedIn = raw.ownerLoggedIn;
  if (typeof raw.seekerLoggedIn === "boolean") safe.seekerLoggedIn = raw.seekerLoggedIn;
  return safe;
}

export function loadPersisted() {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    return sanitize(JSON.parse(raw));
  } catch {
    return null;
  }
}

export function savePersisted(state) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // Storage full or unavailable (private browsing, etc.) — fail silently.
  }
}

export function clearPersisted() {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.removeItem(STORAGE_KEY);
  } catch {
    // ignore
  }
}
